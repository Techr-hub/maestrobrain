// Maestro Control Centre: shell, brain dashboard, chat + voice, and the live intelligence feed.
import { icon, CATEGORY } from './icons.js';
import { renderMarkdown, stripMarkdown, esc } from './md.js';
import { BrainMap, avatar as makeAvatar } from './brainmap.js';
import { Voice, voiceSupported } from './voice.js';
import { S, api, refreshState, toast, timeAgo, modal, modalHead, openNote, wireWikilinks, closeDrawer } from './core.js';
import { PAGES, onboarding, knowledgeModal, connectModal, dueFields, wireDueFields, projectStatus } from './pages.js';
import { monthCalendar } from './calendar-ui.js';

const $ = (s, r = document) => r.querySelector(s);

const NAV = [
  ['dashboard', 'Dashboard', 'layout-grid'],
  ['agents', 'Agents', 'users-round'],
  ['connections', 'MCP Connections', 'plug'],
  ['tasks', 'Tasks', 'clipboard-check'],
  ['calendar', 'Calendar', 'calendar-days'],
  ['projects', 'Projects', 'folder'],
  ['vault', 'Knowledge', 'brain'],
  ['skills', 'Skills & Packs', 'box'],
  ['conversations', 'Conversations', 'message-circle'],
  ['workflows', 'Workflows', 'workflow'],
  ['settings', 'Settings', 'settings'],
];

const SHORT = { gmail: 'GM', outlook: 'OL', email: '@', icalendar: 'iC', gcal: 'GC', calendly: 'CY', slack: '#', twilio_sms: 'TX', whatsapp: 'WA', twilio_calls: 'PH', google_meet: 'MT', teams: 'TM', zoom: 'ZM', linear: 'LN', jira: 'JR', notion: 'N', figma: 'FG', gdrive: 'GD', github: 'GH', docs: 'DC' };

let brain, av, voice, dashboardEl;

// ---------------------------------------------------------------- boot
async function boot() {
  await refreshState();
  S.livePaused = !(S.state.config.demo && S.state.config.demo.liveFeed);
  renderShell();
  buildDashboard();
  const initial = (location.hash || '#dashboard').slice(1);
  navigate(PAGES[initial] || initial === 'dashboard' ? initial : 'dashboard');
  await loadFeed();
  connectStream();
  clock();
  setInterval(clock, 1000);
  setInterval(() => renderFeed(false), 60000); // refresh "x min ago"
  if (!S.state.config.onboarded) onboarding({ after: afterChange });
  else if (!S.state.knowledge.connected) knowledgeModal(() => afterChange({}), { first: true });
}

export async function afterChange({ graph = true, feed = true } = {}) {
  await refreshState();
  renderShell();
  renderMentions();
  updateBrainSources();
  if (graph) loadGraph();
  if (feed) await loadFeed();
  refreshStats();
}

// Collapsible sidebar: icons only when collapsed (the default), remembered per browser.
function applySidebar() {
  let collapsed = true;
  try { collapsed = localStorage.getItem('maestro.sidebar') !== 'open'; } catch { /* storage blocked */ }
  document.querySelector('.workspace').classList.toggle('collapsed', collapsed);
  const t = $('#sidebar-toggle');
  t.title = collapsed ? 'Expand menu' : 'Collapse menu';
  t.querySelector('.toggle-icon').innerHTML = icon(collapsed ? 'panel-left-open' : 'panel-left');
  if (brain) setTimeout(() => brain.resize(), 220);
}
$('#sidebar-toggle').onclick = () => {
  const collapsed = document.querySelector('.workspace').classList.contains('collapsed');
  try { localStorage.setItem('maestro.sidebar', collapsed ? 'open' : 'closed'); } catch { /* storage blocked */ }
  applySidebar();
};

// Top-bar man / woman voice switch (icons only): picks the most natural voice of that kind and says hello in it.
async function setVoiceGender(gender) {
  if (S.state.config.voice.gender === gender && !S.state.config.voice.voiceName) return;
  // A specific voice chosen in Settings would override the switch, so clear it.
  S.state.config.voice = { ...S.state.config.voice, gender, voiceName: '' };
  renderShell();
  try { await api('/settings', { voice: { gender, voiceName: '' } }); } catch { /* the next save retries */ }
  const v = voice.bestVoice(gender);
  toast(v ? `Maestro now speaks as ${v.name.replace(/^Microsoft |^Google /, '').replace(/ Online \(Natural\)| - English.*$/, '')}` : 'Voice saved');
  voice.speak("Hi, it's Maestro. How do I sound?", { gender, rate: S.state.config.voice.rate, pause: S.state.config.voice.pause });
}

function renderShell() {
  applySidebar();
  const st = S.state, cfg = st.config;
  $('#nav').innerHTML = NAV.map(([id, label, ic]) => `<button class="nav-item ${S.route === id ? 'active' : ''}" data-route="${id}" title="${label}">${icon(ic)}<span class="label">${label}</span>${id === 'connections' ? `<span class="badge">${Object.keys(cfg.connections[cfg.profile] || {}).length}</span>` : ''}</button>`).join('');
  $('#nav').querySelectorAll('.nav-item').forEach((b) => b.onclick = () => navigate(b.dataset.route));
  const ps = $('#profile-switch');
  ps.querySelector('[data-profile=business]').innerHTML = `${icon('briefcase')} Business`;
  ps.querySelector('[data-profile=personal]').innerHTML = `${icon('home')} Personal`;
  ps.querySelectorAll('button').forEach((b) => {
    b.classList.toggle('on', b.dataset.profile === cfg.profile);
    b.onclick = () => switchProfile(b.dataset.profile);
  });
  const vs = $('#voice-switch');
  const gender = (cfg.voice && cfg.voice.gender) || 'male';
  vs.querySelector('[data-gender=male]').innerHTML = icon('man'); // icons only (Ryan, 2026-11-02)
  vs.querySelector('[data-gender=female]').innerHTML = icon('woman');
  vs.querySelectorAll('button').forEach((b) => {
    const on = b.dataset.gender === gender;
    b.classList.toggle('on', on); b.setAttribute('aria-checked', String(on));
    b.onclick = () => setVoiceGender(b.dataset.gender);
  });
  $('#bell-icon').innerHTML = icon('bell');
  $('#bell-dot').hidden = !st.unread;
  $('#prefs').innerHTML = icon('settings');
  $('#feed-toggle').innerHTML = icon('panel-right');
  $('#op-dot').innerHTML = icon('circle-dot');
  $('#op-name').textContent = cfg.user.name;
  $('#op-avatar').textContent = (cfg.user.name || '?')[0].toUpperCase();
  $('#arrow').innerHTML = icon('arrow-right');
  $('#live-toggle').innerHTML = `${icon('circle-dot')} ${S.livePaused ? 'PAUSED' : 'LIVE'}`;
  $('#live-toggle').classList.toggle('paused', S.livePaused);
  const rf = $('#feed-refresh');
  rf.innerHTML = icon('refresh');
  rf.onclick = async () => {
    if (rf.classList.contains('spinning')) return;
    rf.classList.add('spinning'); rf.disabled = true;
    try {
      const r = await api('/feed/refresh', {});
      await afterChange(); // feed, brain map, sources and counts
      toast(`${r.added ? `${r.added} new item${r.added === 1 ? '' : 's'}` : 'Up to date'}${r.errors ? ` · ${r.errors} connection${r.errors === 1 ? '' : 's'} need attention` : ''}${r.viaClaude && r.viaClaude.length ? ' · ask Claude Desktop to sync its connectors' : ''}`, r.errors ? 'error' : undefined);
    }
    catch (e) { toast('Could not refresh: ' + e.message, 'error'); }
    finally { rf.classList.remove('spinning'); rf.disabled = false; }
  };
  greet();
}

function greet() {
  const h = new Date().getHours();
  const cfg = S.state.config;
  $('#greet').textContent = `Good ${h < 12 ? 'morning' : h < 17 ? 'afternoon' : 'evening'}, ${cfg.user.name}`;
  const n = S.feed.filter((i) => i.priority === 'High').length;
  $('#greet-sub').textContent = cfg.profile === 'personal' ? 'Personal mode: work stays at work.' : n ? `${n} things need you today. Let's make it extraordinary.` : "Let's make today extraordinary.";
}

function clock() {
  const d = new Date();
  $('#clock-date').textContent = d.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  $('#clock-time').textContent = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', second: '2-digit' });
}

export function navigate(route) {
  S.route = route;
  history.replaceState(null, '', '#' + route);
  closeDrawer();
  $('#nav').querySelectorAll('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.route === route));
  const main = $('#main');
  if (route === 'dashboard') {
    main.replaceChildren(dashboardEl);
    requestAnimationFrame(() => brain && brain.resize());
    // a project just created (or given a task) lights its node with the glow beam
    if (S.pendingPulse && brain) { const id = S.pendingPulse; S.pendingPulse = null; setTimeout(() => brain.pulseSource(id, '#00f2af'), 450); }
    $('#chat-input') && $('#chat-input').focus();
  } else {
    const page = document.createElement('div');
    page.className = 'page';
    main.replaceChildren(page);
    PAGES[route](page, { navigate, afterChange, ask, newConversation, createTask: eventTaskForm });
  }
}

async function switchProfile(profile) {
  if (profile === S.state.config.profile) return;
  await api('/profile', { profile });
  toast(profile === 'personal' ? 'Personal mode: only personal sources and notes' : 'Business mode: work sources and notes');
  await afterChange();
  if (S.route !== 'dashboard') navigate(S.route);
}

// ---------------------------------------------------------------- dashboard
function buildDashboard() {
  dashboardEl = document.createElement('div');
  dashboardEl.className = 'brain';
  dashboardEl.innerHTML = `
    <canvas class="brain-canvas" id="brain-canvas"></canvas>
    <div class="brain-tooltip" id="brain-tip"></div>
    <div class="brain-stats" id="brain-stats"></div>
    <div class="subtitle online" id="subtitle"><i class="dot"></i>Maestro Online</div>
    <div class="chat-panel" id="chat-panel">
      <div class="chat-bar" id="chat-bar" hidden><span>${icon('message-circle')} Conversation</span><button id="chat-toggle" title="Hide or show the conversation">${icon('chevron-down')} Hide</button><button id="chat-new" title="Start a new conversation">${icon('plus')} New</button></div>
      <div class="chat-log" id="chat-log" aria-live="polite"></div>
      <div class="composer">
        <div class="composer-row">
          <div class="input-wrap">
            <input id="chat-input" autocomplete="off" placeholder="Message ${esc(S.state.config.assistantName)} or an agent..." aria-label="Message">
            <button class="ghost" id="attach" title="Import a Markdown file (agent, skill or note)">${icon('paperclip')}</button>
            <input type="file" id="file" accept=".md,.markdown,.txt" hidden>
          </div>
          <button class="mic-btn ${voice && voice.active ? 'listening' : ''}" id="mic" aria-pressed="${!!(voice && voice.active)}" title="Talk to your brain. Click once to keep the mic on, again to turn it off (Alt+V)">${icon('mic')}</button>
          <button class="send-btn" id="send" title="Send">${icon('send')}</button>
        </div>
        <div class="mentions" id="mentions"></div>
      </div>
    </div>`;

  brain = new BrainMap(dashboardEl.querySelector('#brain-canvas'), {
    tooltip: dashboardEl.querySelector('#brain-tip'),
    onNodeClick: (n) => { S.sourceBack = null; return n.kind === 'note' ? openNote(n.id) : showSource(n.id); }, // a project node shows just its card (Ryan, 2026-11-04) // hubs use 'hub:<id>'
    onLayout: (b) => { const st = dashboardEl.querySelector('#subtitle'); if (st) { st.style.top = b.subY + 'px'; st.style.left = b.subX + 'px'; } },
  });
  window.maestroBrain = brain;
  api('/hubs').then((h) => { S.hubs = h; updateBrainSources(); }).catch(() => {}); // handy for debugging in the browser console
  av = makeAvatar($('#avatar-canvas'));
  $('#brand-avatar').onclick = () => { navigate('dashboard'); toggleMic(); };

  const input = dashboardEl.querySelector('#chat-input');
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendFromInput(); } });
  dashboardEl.querySelector('#send').onclick = sendFromInput;
  dashboardEl.querySelector('#mic').onclick = toggleMic;
  dashboardEl.querySelector('#attach').onclick = () => dashboardEl.querySelector('#file').click();
  dashboardEl.querySelector('#file').onchange = importFile;

  dashboardEl.querySelector('#chat-toggle').onclick = () => {
    const panel = dashboardEl.querySelector('#chat-panel');
    panel.classList.toggle('collapsed');
    const c = panel.classList.contains('collapsed');
    dashboardEl.querySelector('#chat-toggle').innerHTML = `${icon(c ? 'chevron-up' : 'chevron-down')} ${c ? 'Show' : 'Hide'}`;
    brain.setCompact(!c);
  };
  dashboardEl.querySelector('#chat-new').onclick = () => { newConversation(); };
  renderMentions();
  renderSuggestions();
  updateBrainSources();
  loadGraph();
  setupVoice();

  document.addEventListener('keydown', (e) => {
    if (e.altKey && e.code === 'KeyV') { e.preventDefault(); navigate('dashboard'); toggleMic(); }
    if (e.key === '/' && !/input|textarea|select/i.test(document.activeElement.tagName)) { e.preventDefault(); navigate('dashboard'); input.focus(); }
  });
}

async function loadGraph() {
  const g = await api('/graph');
  brain.setGraph(g);
  brain._noteCount = g.nodes.length;
  updateStats();
  refreshStats();
}

// Shades of a hub's colour for its sub-categories: lighter to darker around the base hue.
function shade(hexColor, i, n) {
  const v = parseInt(hexColor.slice(1), 16);
  let r = ((v >> 16) & 255) / 255, g = ((v >> 8) & 255) / 255, b = (v & 255) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, sat = 0, l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    sat = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h /= 6;
  }
  l = Math.min(0.85, Math.max(0.3, l + (n > 1 ? 0.22 - (0.44 * i) / (n - 1) : 0.12)));
  const q = l < 0.5 ? l * (1 + sat) : l + sat - l * sat, p = 2 * l - q;
  const f = (t) => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
  return '#' + [f(h + 1 / 3), f(h), f(h - 1 / 3)].map((x) => Math.round(x * 255).toString(16).padStart(2, '0')).join('');
}

const initials = (name) => String(name).split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('') || 'PR';
function updateBrainSources() {
  const cfg = S.state.config;
  const conns = cfg.connections[cfg.profile] || {};
  // Five default hubs always sit on the orbit. Each source joins the map, next to its hub, only once it's connected.
  const hubs = S.hubs || [];
  const list = hubs.map((h) => ({ id: 'hub:' + h.id, name: h.name, color: h.color, short: h.short, hub: true, members: h.members,
    connected: h.projects || h.members.some((m) => conns[m]), error: h.members.some((m) => conns[m] && conns[m].lastError) }));
  for (const h of hubs) {
    // Sub-categories: the hub's "always" ones (e.g. Calls → Meet, Phone, Teams, Zoom) plus anything connected.
    const subs = h.members.filter((m) => conns[m] || (h.always || []).includes(m));
    subs.forEach((m, i) => {
      const c = S.state.connectors.find((x) => x.id === m);
      if (!c) return;
      list.push({ id: m, name: c.short || c.name, color: shade(h.color, i, subs.length), short: SHORT[m], parent: 'hub:' + h.id, connected: !!conns[m], error: !!(conns[m] && conns[m].lastError) });
    });
  }
  // Projects made on the Projects page attach to the Projects hub (Ryan, 2026-11-04).
  const projHub = hubs.find((h) => h.projects);
  if (projHub) {
    const mine = (S.state.projects || []).filter((p) => p.made).slice(0, 10);
    mine.forEach((p, i) => list.push({ id: 'project:' + p.path, name: p.name, color: shade(projHub.color, i, mine.length), short: initials(p.name), parent: 'hub:' + projHub.id, connected: true, project: p.path }));
  }
  brain && brain.setSources(list);
  updateStats();
}

function updateStats() {
  if (!dashboardEl) return;
  const st = S.stats || { notes: brain._noteCount || 0, sources: Object.keys(S.state.config.connections[S.state.config.profile] || {}).length, agents: S.state.agents.length, skills: S.state.skills.length };
  $('#brain-stats', dashboardEl).innerHTML = [[st.notes, 'Notes'], [st.sources, 'Sources'], [st.agents, 'Agents'], [st.skills, 'Skills']]
    .map(([v, l]) => `<div class="stat"><b>${v}</b><small>${l}</small></div>`).join('');
}
// Fresh counts from the server (Ryan, 2026-11-03): on load, after changes, every 15 s and when you come back to the tab,
// so notes added in Obsidian or agents made in Claude Desktop show up without a reload.
async function refreshStats() {
  try { S.stats = await api('/stats'); updateStats(); } catch { /* older server: keep the local counts */ }
}
setInterval(() => { if (!document.hidden) refreshStats(); }, 15000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshStats(); });

function renderMentions() {
  const el = dashboardEl && $('#mentions', dashboardEl);
  if (!el) return;
  const agents = S.state.agents;
  el.innerHTML = agents.slice(0, 6).map((a) => `<button class="mention ${S.agent === a.handle ? 'on' : ''}" data-h="${esc(a.handle)}" style="--agent:${esc(a.color)}" title="${esc(a.description || a.role)}">@${esc(a.handle)}</button>`).join('') +
    `<button class="mention" id="more-agents" title="All agents">•••</button><span class="hint">${voiceSupported.stt ? 'Alt+V to talk · / to type' : 'Voice needs Chrome or Edge'}</span>`;
  el.querySelectorAll('[data-h]').forEach((b) => b.onclick = () => {
    S.agent = S.agent === b.dataset.h ? null : b.dataset.h;
    if (S.agent && S.agent.toLowerCase() === S.state.config.assistantName.toLowerCase()) S.agent = null;
    renderMentions();
    const input = $('#chat-input', dashboardEl);
    input.placeholder = S.agent ? `Message @${S.agent}...` : `Message ${S.state.config.assistantName} or an agent...`;
    input.focus();
  });
  $('#more-agents', el).onclick = () => navigate('agents');
}

// The quick-question chips above the chat box were removed (Ryan, 2026-11-02).
function renderSuggestions() {}

function setSubtitle(text, speaking = false, online = false) {
  const el = $('#subtitle', dashboardEl);
  el.textContent = text;
  if (online) el.insertAdjacentHTML('afterbegin', '<i class="dot"></i>');
  el.classList.toggle('speaking', speaking);
  el.classList.toggle('online', online);
}

function setBrainState(state) {
  brain.setState(state);
  // The sidebar logo stays still; only the brain core in the map reacts to voice.
  const label = { idle: 'Maestro Online', listening: 'Listening…', thinking: 'Thinking…', speaking: '' }[state];
  if (label !== '') setSubtitle(label, false, state === 'idle');
}

// ---------------------------------------------------------------- chat
function sendFromInput() {
  const input = $('#chat-input', dashboardEl);
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  ask(text);
}

export function newConversation() {
  S.conversationId = null;
  $('#chat-log', dashboardEl).innerHTML = '';
  $('#chat-bar', dashboardEl).hidden = true;
  $('#chat-panel', dashboardEl).classList.remove('collapsed');
  brain.setCompact(false);
  renderSuggestions();
}

function addMessage(role, html, extra = {}) {
  const log = $('#chat-log', dashboardEl);
  $('#chat-bar', dashboardEl).hidden = false;
  if (!$('#chat-panel', dashboardEl).classList.contains('collapsed')) brain.setCompact(true);
  const div = document.createElement('div');
  div.className = 'msg ' + (role === 'user' ? 'user' : 'bot');
  if (extra.color) div.style.setProperty('--agent', extra.color);
  div.innerHTML = html;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
  renderSuggestions();
  return div;
}

export async function ask(text, { voice: viaVoice = false } = {}) {
  if (S.route !== 'dashboard') navigate('dashboard');
  const handle = S.agent && !/^@/.test(text) ? S.agent : null;
  addMessage('user', esc(handle ? `@${handle} ${text}` : text));
  const pending = addMessage('bot', `<div class="who">${esc(handle || S.state.config.assistantName)}</div><span class="typing"><i></i><i></i><i></i></span>`);
  setBrainState('thinking');
  let res;
  try {
    res = await api('/chat', { message: text, agent: handle, conversationId: S.conversationId, voice: viaVoice });
  } catch (e) {
    pending.innerHTML = `<div class="who">Error</div>${esc(e.message)}`;
    setBrainState('idle');
    return;
  }
  S.conversationId = res.conversationId;
  const agent = res.agent || { name: S.state.config.assistantName, handle: S.state.config.assistantName, color: '#00e5ff' };
  pending.style.setProperty('--agent', agent.color);
  const providerLabel = { demo: 'demo brain', memory: 'memory', tasks: 'tasks', anthropic: 'Claude', openai: 'ChatGPT', gemini: 'Gemini', compatible: S.state.config.llm.compatible.label || 'custom model' }[res.provider] || res.provider;
  const head = `<div class="who">${esc(agent.name)} <small>${esc(providerLabel)}</small></div>`;
  const body = document.createElement('div');
  body.className = 'md';
  pending.innerHTML = head;
  pending.appendChild(body);
  if (res.sources.length) brain.highlightNotes(res.sources);
  brain.flashCore();
  if (res.actions.some((a) => a.type === 'memory' || a.type === 'task')) loadGraph();
  if (res.actions.some((a) => a.type === 'event')) brain.pulseSource('hub:calendar', '#00e5ff');

  // "Create a task for <event or card>" (Ryan, 2026-11-02): the Create Task form opens while Maestro asks for the note.
  const openTask = res.actions.find((a) => a.type === 'open-task');
  if (openTask) eventTaskForm(openTask.item, { prompt: stripMarkdown(res.reply), viaVoice });
  // "Talking back": the logo spins while the answer is written out and/or spoken.
  setBrainState('speaking');
  const spoken = stripMarkdown(res.reply);
  setSubtitle(spoken.split(/(?<=[.!?])\s/)[0].slice(0, 140), true);
  const speakIt = !openTask && viaVoice && S.state.config.voice.speakReplies && voiceSupported.tts; // the task form says it itself
  if (speakIt) {
    voice.speak(spoken, { voiceName: S.state.config.voice.voiceName, gender: S.state.config.voice.gender, rate: S.state.config.voice.rate, pause: S.state.config.voice.pause, onStart: () => setBrainState('speaking'), onEnd: () => setBrainState(voice.active ? 'listening' : 'idle') });
  }
  await typeOut(body, res.reply);
  if (!speakIt) setTimeout(() => { if (brain.state === 'speaking') setBrainState('idle'); }, 600);

  const tools = document.createElement('div');
  tools.className = 'tools';
  tools.innerHTML = res.sources.slice(0, 5).map((p) => `<button data-src="${esc(p)}">${icon('file-text')} ${esc(p.split('/').pop().replace('.md', ''))}</button>`).join('') +
    `<button data-act="speak">${icon('volume-2')} Speak</button><button data-act="save">${icon('save')} Save to vault</button><button data-act="copy">${icon('copy')} Copy</button>`;
  // Overview replies end with "Which do you want to hear more about: a, b or c?" Offer those as one-tap follow-ups.
  const follow = res.reply.match(/hear more about: ([^?\n]+)\?/i);
  if (follow) {
    const opts = follow[1].split(/,\s*|\s+or\s+/).map((s) => s.trim()).filter(Boolean);
    const row = document.createElement('div');
    row.className = 'suggestions followups';
    row.innerHTML = opts.map((o) => `<button class="suggestion" data-q="${esc(o)}">${esc(o[0].toUpperCase() + o.slice(1))}</button>`).join('') + '<button class="suggestion" data-q="everything">Everything</button>';
    row.querySelectorAll('[data-q]').forEach((b) => b.onclick = () => { row.remove(); ask(b.dataset.q, { voice: viaVoice }); });
    pending.appendChild(row);
  }
  pending.appendChild(tools);
  tools.querySelectorAll('[data-src]').forEach((b) => b.onclick = () => openNote(b.dataset.src));
  tools.querySelector('[data-act=speak]').onclick = () => {
    setBrainState('speaking');
    voice.speak(spoken, { voiceName: S.state.config.voice.voiceName, gender: S.state.config.voice.gender, rate: S.state.config.voice.rate, pause: S.state.config.voice.pause, onEnd: () => setBrainState('idle') });
  };
  tools.querySelector('[data-act=save]').onclick = async () => {
    const r = await api('/chat/save', { title: text.slice(0, 60), content: res.reply });
    toast('Saved to ' + r.path); loadGraph();
  };
  tools.querySelector('[data-act=copy]').onclick = () => { navigator.clipboard.writeText(res.reply); toast('Copied'); };
  wireWikilinks(pending);
  $('#chat-log', dashboardEl).scrollTop = 1e9;
}

function typeOut(el, text) {
  return new Promise((resolve) => {
    const total = text.length;
    const step = Math.max(6, Math.round(total / 70));
    let i = 0;
    const log = $('#chat-log', dashboardEl);
    const tick = () => {
      i = Math.min(total, i + step);
      el.innerHTML = renderMarkdown(text.slice(0, i));
      log.scrollTop = log.scrollHeight;
      if (i < total) setTimeout(tick, 16); else resolve();
    };
    tick();
  });
}

async function importFile(e) {
  const f = e.target.files[0];
  e.target.value = '';
  if (!f) return;
  const content = await f.text();
  const isDef = /^---[\s\S]*?(name|handle|triggers):/m.test(content);
  if (isDef) {
    const r = await api('/import', { filename: f.name, content });
    toast(`Imported ${r.kind}: ${r.path}`);
    await afterChange({ feed: false });
  } else {
    const r = await api('/vault/note', { path: 'Inbox/' + f.name.replace(/\.(txt|markdown)$/i, '.md'), content });
    toast('Added to your vault: ' + r.path);
    $('#chat-input', dashboardEl).value = `Summarise [[${f.name.replace(/\.(md|txt|markdown)$/i, '')}]] and tell me what matters`;
    loadGraph();
  }
}

// ---------------------------------------------------------------- voice
function setupVoice() {
  voice = new Voice({
    lang: S.state.config.voice.lang || 'en-US',
    onInterim: (t) => { setSubtitle(t, true); $('#chat-input', dashboardEl).value = t; },
    onFinal: (t) => { $('#chat-input', dashboardEl).value = ''; ask(t, { voice: true }); }, // the mic stays on until you switch it off
    onInterrupt: () => { setBrainState('listening'); setSubtitle('Listening…', true); },
    onLevel: (v) => { brain.setLevel(v); },
    onState: (s, err) => {
      $('#mic', dashboardEl).classList.toggle('listening', s === 'listening');
      if (s === 'error') { toast('Microphone: ' + err, 'error'); setBrainState('idle'); }
      else if (s === 'listening') setBrainState('listening');
      else if (brain.state === 'listening') setBrainState('idle');
    },
  });
  voice.wakeName = S.state.config.assistantName.toLowerCase();
}

function toggleMic() {
  if (!voiceSupported.stt) return toast('Voice input needs Chrome or Edge. You can still type.', 'error');
  const mic = $('#mic', dashboardEl);
  // The mic button is an on/off switch: on, you can talk to Maestro at any point, even while it's speaking.
  if (voice.active || voice.listening) {
    voice.stop(); voice.stopSpeaking(); setBrainState('idle');
    if (mic) { mic.classList.remove('listening'); mic.title = 'Talk to your brain (Alt+V)'; mic.setAttribute('aria-pressed', 'false'); }
    toast('Mic off');
    return;
  }
  try {
    voice.wakeName = S.state.config.assistantName.toLowerCase();
    const wake = !!S.state.config.voice.handsFree;
    voice.start({ wakeWord: wake });
    if (mic) { mic.title = 'Mic is on: talk any time. Click to turn it off (Alt+V)'; mic.setAttribute('aria-pressed', 'true'); }
    toast(wake ? `Mic on. Start with "Hey ${S.state.config.assistantName}…". Click the mic again to turn it off.` : 'Mic on. Talk any time, or talk over me to interrupt. Click the mic again to turn it off.');
  } catch (e) { toast(e.message, 'error'); }
}

// ---------------------------------------------------------------- intelligence feed
async function loadFeed() {
  S.feed = await api('/feed?limit=400');
  fillSourceFilter();
  renderFeed(false);
  greet();
}

// Add items to the feed without duplicates, newest first.
function mergeFeed(items) {
  const ids = new Set(items.map((i) => i.id));
  S.feed = [...items, ...S.feed.filter((x) => !ids.has(x.id))].sort((a, b) => b.ts - a.ts);
}

function fillSourceFilter() {
  const cfg = S.state.config;
  const conns = cfg.connections[cfg.profile] || {};
  const sel = $('#source-filter');
  const opts = [['all', 'All Sources'], ['projects', 'Projects'], ...S.state.connectors.filter((c) => conns[c.id]).map((c) => [c.id, c.name.replace(/ \(.*\)/, '')]), ['system', 'Maestro']];
  sel.innerHTML = opts.map(([v, l]) => `<option value="${v}" ${S.source === v ? 'selected' : ''}>${esc(l)}</option>`).join('');
  sel.onchange = async () => {
    S.sourceView = null; S.source = sel.value;
    if (S.source === 'projects') { try { mergeFeed(await api('/feed?category=PROJECT&limit=400')); } catch {} }
    else if (S.source !== 'all') { // pull that source's own history, so older cards aren't hidden behind the 80-item window
      try { mergeFeed(await api(`/feed?source=${encodeURIComponent(S.source)}&limit=400`)); } catch {}
    }
    renderFeed(false);
  };
}

// Small marks for each calendar so cards from different calendars are easy to tell apart.
const CAL_MARK = {
  gcal: (d) => `<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1" y="1" width="14" height="14" rx="3" fill="#fff"/><path d="M1 4a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3v1H1z" fill="#4285f4"/><path d="M15 12v1a2 2 0 0 1-2 2h-2l4-4z" fill="#34a853"/><path d="M1 12v1a2 2 0 0 0 2 2h2l-4-4z" fill="#fbbc04"/><text x="8" y="12.4" text-anchor="middle" font-size="7" font-weight="700" font-family="Arial,sans-serif" fill="#4285f4">${d}</text></svg>`,
  icalendar: (d) => `<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1" y="1" width="14" height="14" rx="3" fill="#fff"/><path d="M1 4a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3v1.5H1z" fill="#ff3b30"/><text x="8" y="13" text-anchor="middle" font-size="7.5" font-weight="700" font-family="Arial,sans-serif" fill="#1c1c1e">${d}</text></svg>`,
  outlook: () => `<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1" y="1" width="14" height="14" rx="3" fill="#0f6cbd"/><circle cx="8" cy="8" r="3.6" fill="none" stroke="#fff" stroke-width="1.8"/></svg>`,
  calendly: () => `<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7" fill="#006bff"/><path d="M10.6 5.6A3.4 3.4 0 1 0 10.6 10.4" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/></svg>`,
  maestro: () => `<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1" y="1" width="14" height="14" rx="3" fill="#00f2af"/><text x="8" y="11.6" text-anchor="middle" font-size="8" font-weight="700" font-family="Arial,sans-serif" fill="#01121c">M</text></svg>`,
};
function sourceChip(i) {
  const c = S.state && S.state.connectors.find((x) => x.id === i.source);
  const color = i.source === 'maestro' ? '#00f2af' : (c && c.color) || '#00e5ff';
  const mark = CAL_MARK[i.source] ? CAL_MARK[i.source](new Date().getDate()) : icon((c && c.icon) || (i.source === 'system' ? 'brain' : 'plug'));
  const name = (i.sourceName || '').replace(/ \(.*\)/, '').replace(' / Microsoft 365', '');
  return `<span class="src-chip ${CAL_MARK[i.source] ? 'cal' : ''}" style="--sc:${color}">${mark}<b>${esc(name)}</b>${i.calendarName ? `<i>${esc(i.calendarName)}</i>` : ''}</span>`;
}

// Which brain section a card's tasks go under on the Tasks page (Ryan, 2026-11-02).
const SECTION_OF = { MEETING: 'calendar', EMAIL: 'email', CONVERSATION: 'messages', SMS: 'messages', CALL: 'calls', PROJECT: 'projects', TASK: 'projects' };
function sectionOf(item) { return SECTION_OF[item.category] || (CAL_MARK[item.source] ? 'calendar' : ''); }

// The X on a card clears it from the feed for good (Ryan, 2026-11-02). One listener covers every feed list.
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-dismiss]');
  if (!b) return;
  e.stopPropagation(); e.preventDefault();
  const id = b.dataset.dismiss, card = b.closest('.activity');
  if (card) { card.classList.add('dismissing'); await new Promise((r) => setTimeout(r, 180)); }
  S.feed = S.feed.filter((x) => x.id !== id);
  renderFeed(false);
  try { await api('/feed/dismiss', { id }); } catch (err) { toast('Could not clear it: ' + err.message, 'error'); }
}, true);

// ---------------------------------------------------------------- event types (Ryan, 2026-11-04)
// Calendar cards are labelled Meeting, Event, Conference, Workshop, Call… (read from the event's title and description).
// The label is a dropdown: pick another type for that event, or edit the list of types.
const eventTypes = () => S.state.eventTypes || [];
function typePill(i) {
  if (i.category !== 'MEETING' || !i.eventType) return '';
  const t = eventTypes().find((x) => x.id === i.eventType);
  if (!t) return '';
  return `<button class="pill type-pill" data-type style="--tc:${t.color}" aria-haspopup="menu" title="Change the category">${esc(t.name.toUpperCase())}${icon('chevron-down')}</button>`;
}
// ⋮ on event cards (Ryan, 2026-11-06): a small menu with Edit and Delete for the event itself.
const isEventCard = (i) => i.category === 'MEETING' && !i.removed && !i.reminder;
const eventRef = (item) => ({ source: item.source, key: item.eventKey || '', start: item.eventStart || '', title: item.eventTitle || item.title, cardId: item.id });
function eventMenu(btn, item) {
  const was = document.querySelector('.type-menu');
  closeTypeMenu();
  if (was && was.dataset.for === 'ev:' + item.id) return;
  const m = document.createElement('div');
  m.className = 'type-menu ev-menu'; m.setAttribute('role', 'menu'); m.dataset.for = 'ev:' + item.id;
  m.innerHTML = `<button role="menuitem" data-ev-edit>${icon('pencil')} Edit event</button><button role="menuitem" class="danger" data-ev-del>${icon('trash')} Delete event</button>`;
  document.body.appendChild(m);
  const r = btn.getBoundingClientRect(), w = m.offsetWidth, h = m.offsetHeight;
  m.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w)) + 'px';
  m.style.top = (r.bottom + 6 + h > window.innerHeight - 8 ? Math.max(8, r.top - h - 6) : r.bottom + 6) + 'px';
  m.querySelector('[data-ev-edit]').onclick = () => { closeTypeMenu(); editEvent(item); };
  m.querySelector('[data-ev-del]').onclick = () => { closeTypeMenu(); deleteEvent(item); };
  m.querySelector('button').focus();
  setTimeout(() => { document.addEventListener('mousedown', typeMenuOutside, true); document.addEventListener('keydown', typeMenuKey, true); });
}
const pad2 = (n) => String(n).padStart(2, '0');
const localDay = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const localTime = (d) => `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
async function lookupEvent(item) {
  const e = await api('/events/find', eventRef(item));
  if (!e || e.error) throw new Error((e && e.error) || "I couldn't find that event.");
  return e;
}
async function editEvent(item) {
  let e;
  try { e = await lookupEvent(item); } catch (err) { return toast(err.message, 'error'); }
  const s = new Date(e.start), en = new Date(e.end);
  modal(`${modalHead('Edit event', esc(e.where || ''))}
    <div class="field"><label for="ee-title">Title</label><input class="input" id="ee-title" value="${esc(e.title)}"></div>
    <div class="due-fields">
      <div class="field"><label for="ee-day">Date</label><input class="input" type="date" id="ee-day" value="${localDay(s)}"></div>
      <div class="field"><label for="ee-start">Starts</label><input class="input" type="time" id="ee-start" step="300" value="${localTime(s)}"${e.allDay ? ' disabled' : ''}></div>
      <div class="field"><label for="ee-end">Ends</label><input class="input" type="time" id="ee-end" step="300" value="${localTime(en)}"${e.allDay ? ' disabled' : ''}></div>
    </div>
    <div class="field"><label for="ee-loc">Location</label><input class="input" id="ee-loc" value="${esc(e.location || '')}" placeholder="Room, address or meeting link"></div>
    <div class="field"><label for="ee-desc">Description</label><textarea class="input" id="ee-desc" rows="4">${esc(e.description || '')}</textarea></div>
    <div class="modal-foot"><button class="btn ghost" data-close>Cancel</button><button class="btn primary" id="ee-save">${icon('save')} Save changes</button></div>`, {
    onMount: (el, close) => {
      const v = (id) => el.querySelector(id).value;
      setTimeout(() => el.querySelector('#ee-title').focus(), 50);
      el.querySelector('#ee-save').onclick = async () => {
        const day = v('#ee-day');
        if (!v('#ee-title').trim()) return toast('Give the event a title', 'error');
        if (!day) return toast('Pick a date', 'error');
        let start, end;
        if (e.allDay) { const len = en - s; start = new Date(`${day}T00:00`); end = new Date(+start + len); }
        else {
          start = new Date(`${day}T${v('#ee-start') || localTime(s)}`); end = new Date(`${day}T${v('#ee-end') || localTime(en)}`);
          if (end <= start) end = new Date(+end + 86400000); // ends after midnight
        }
        const btn = el.querySelector('#ee-save'); btn.disabled = true;
        try {
          const r = await api('/events/update', { ...eventRef(item), fields: { title: v('#ee-title'), start: start.toISOString(), end: end.toISOString(), location: v('#ee-loc'), description: v('#ee-desc') } });
          close(); toast(`Event updated. ${r.note || ''}`.trim());
          if (S.route === 'calendar') navigate('calendar');
        } catch (err) { btn.disabled = false; toast(err.message, 'error'); }
      };
    },
  });
}
async function deleteEvent(item) {
  let e;
  try { e = await lookupEvent(item); } catch (err) { return toast(err.message, 'error'); }
  const when = new Date(e.start).toLocaleString([], { weekday: 'long', month: 'short', day: 'numeric', ...(e.allDay ? {} : { hour: 'numeric', minute: '2-digit' }) });
  modal(`${modalHead('Delete event?', '')}
    <p style="margin:0 0 6px"><b>${esc(e.title)}</b></p><p style="margin:0;color:var(--muted)">${esc(when)}${e.calendarName ? ` · ${esc(e.calendarName)}` : ''}</p>
    ${e.recurring ? '<p style="color:var(--muted)">This is a repeating event.</p>' : ''}
    <div class="modal-foot"><button class="btn ghost" data-close>Cancel</button>${e.recurring ? `<button class="btn danger" data-del="1">${icon('trash')} Every date</button><button class="btn danger" data-del="0">${icon('trash')} Just this one</button>` : `<button class="btn danger" data-del="0">${icon('trash')} Delete event</button>`}</div>`, {
    onMount: (el, close) => el.querySelectorAll('[data-del]').forEach((b) => (b.onclick = async () => {
      el.querySelectorAll('[data-del]').forEach((x) => (x.disabled = true));
      try {
        const r = await api('/events/delete', { ...eventRef(item), series: b.dataset.del === '1' });
        close(); toast([r.done, r.note].filter(Boolean).join(' '));
        if (S.route === 'calendar') navigate('calendar');
      } catch (err) { el.querySelectorAll('[data-del]').forEach((x) => (x.disabled = false)); toast(err.message, 'error'); }
    })),
  });
}

function closeTypeMenu() { document.querySelectorAll('.type-menu').forEach((m) => m.remove()); document.removeEventListener('mousedown', typeMenuOutside, true); document.removeEventListener('keydown', typeMenuKey, true); }
function typeMenuOutside(e) { if (!e.target.closest('.type-menu')) closeTypeMenu(); }
function typeMenuKey(e) { if (e.key === 'Escape') { e.stopPropagation(); closeTypeMenu(); } }
function typeMenu(btn, item) {
  const was = document.querySelector('.type-menu');
  closeTypeMenu();
  if (was && was.dataset.for === item.id) return; // a second click closes it
  const m = document.createElement('div');
  m.className = 'type-menu'; m.setAttribute('role', 'menu'); m.dataset.for = item.id;
  m.innerHTML = eventTypes().map((t) => `<button role="menuitemradio" aria-checked="${t.id === item.eventType}" data-t="${esc(t.id)}" style="--tc:${t.color}"><i></i>${esc(t.name)}${t.id === item.eventType ? icon('check') : ''}</button>`).join('')
    + `<hr><button role="menuitem" data-edit>${icon('pencil')} Edit categories…</button>`;
  document.body.appendChild(m);
  const r = btn.getBoundingClientRect();
  const w = m.offsetWidth, h = m.offsetHeight;
  m.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w)) + 'px';
  m.style.top = (r.bottom + 6 + h > window.innerHeight - 8 ? Math.max(8, r.top - h - 6) : r.bottom + 6) + 'px';
  m.querySelectorAll('[data-t]').forEach((b) => b.onclick = async () => {
    closeTypeMenu();
    const type = b.dataset.t;
    if (type === item.eventType) return;
    const same = (x) => x.source === item.source && (item.eventKey ? x.eventKey === item.eventKey : x.id === item.id);
    S.feed.forEach((x) => { if (same(x)) x.eventType = type; });
    ((S.sourceData && S.sourceData.items) || []).forEach((x) => { if (same(x)) x.eventType = type; });
    renderFeed(false);
    try { await api('/feed/event-type', { id: item.id, type }); } catch (err) { toast('Could not change it: ' + err.message, 'error'); }
  });
  m.querySelector('[data-edit]').onclick = () => { closeTypeMenu(); editEventTypes(); };
  (m.querySelector('[aria-checked=true]') || m.querySelector('button')).focus();
  setTimeout(() => { document.addEventListener('mousedown', typeMenuOutside, true); document.addEventListener('keydown', typeMenuKey, true); });
}
function editEventTypes() {
  let rows = eventTypes().map((t) => ({ ...t, words: (t.words || []).join(', ') }));
  const rowHtml = (t, k) => `<div class="et-row" data-k="${k}">
      <input type="color" class="et-color" value="${esc(t.color)}" aria-label="Colour">
      <input class="input et-name" value="${esc(t.name)}" placeholder="Name" aria-label="Category name" maxlength="30">
      <input class="input et-words" value="${esc(t.words)}" placeholder="Words that pick it, e.g. webinar, demo" aria-label="Words that pick this category">
      <button class="icon-btn et-del" title="Remove" aria-label="Remove ${esc(t.name)}">${icon('trash')}</button></div>`;
  modal(`${modalHead('Event categories', 'Calendar cards get the category whose words appear in the event title or description. Rename, recolour, add or remove them.')}
    <div class="et-list"></div>
    <button class="btn ghost" data-add>${icon('plus')} Add category</button>
    <div class="modal-foot"><button class="btn ghost" data-reset>Reset to defaults</button><button class="btn primary" data-save>Save</button></div>`, {
    wide: true,
    onMount: (el, close) => {
      const list = el.querySelector('.et-list');
      const read = () => { rows = [...list.querySelectorAll('.et-row')].map((r) => ({ ...rows[Number(r.dataset.k)], color: r.querySelector('.et-color').value, name: r.querySelector('.et-name').value, words: r.querySelector('.et-words').value })); };
      const draw = () => {
        list.innerHTML = rows.map(rowHtml).join('');
        list.querySelectorAll('.et-del').forEach((b) => b.onclick = () => { read(); if (rows.length < 2) return toast('Keep at least one category.', 'error'); rows.splice(Number(b.closest('.et-row').dataset.k), 1); draw(); });
      };
      draw();
      el.querySelector('[data-add]').onclick = () => { read(); rows.push({ name: '', color: '#8bb8ff', words: '' }); draw(); list.querySelector('.et-row:last-child .et-name').focus(); };
      el.querySelector('[data-reset]').onclick = async () => { try { rows = (await api('/event-types/defaults')).map((t) => ({ ...t, words: t.words.join(', ') })); draw(); } catch (err) { toast(err.message, 'error'); } };
      el.querySelector('[data-save]').onclick = async () => {
        read();
        try {
          S.state.eventTypes = await api('/event-types', { types: rows.filter((r) => r.name.trim()).map((r) => ({ id: r.id, name: r.name, color: r.color, words: r.words.split(',') })) });
          close(); toast('Categories saved');
          await loadFeed();
        } catch (err) { toast(err.message, 'error'); }
      };
    },
  });
}

// One card's buttons, the same in the main feed and in a source or hub view (Ryan, 2026-11-04: the category dropdown
// did nothing in the Calendar hub view because only the main feed wired it).
const cardItem = (id) => S.feed.find((x) => x.id === id) || ((S.sourceData && S.sourceData.items) || []).find((x) => x.id === id);
function wireCard(el) {
  const item = cardItem(el.dataset.id);
  if (!item) return;
  el.onclick = (e) => { if (e.target.closest('[data-action],[data-pin],[data-type],[data-dismiss],[data-more]')) return; openFeedItem(item); };
  const more = el.querySelector('[data-more]');
  if (more) more.onclick = (e) => { e.stopPropagation(); eventMenu(more, item); };
  const tp = el.querySelector('[data-type]');
  if (tp) tp.onclick = (e) => { e.stopPropagation(); typeMenu(tp, item); };
  const pin = el.querySelector('[data-pin]');
  if (pin) pin.onclick = async (e) => {
    e.stopPropagation();
    const pinned = !item.pinned;
    for (const x of [S.feed.find((y) => y.id === item.id), item]) if (x) Object.assign(x, { pinned, pinnedAt: pinned ? Date.now() : 0 });
    renderFeed(false);
    try { await api('/feed/pin', { id: item.id, pinned }); } catch (err) { toast('Could not pin: ' + err.message, 'error'); }
  };
  el.querySelectorAll('[data-action]').forEach((b) => b.onclick = async (e) => {
    e.stopPropagation();
    if (b.dataset.action === 'Add Task') { markRead(item); return eventTaskForm(item); } // note, action items, deadline
    if (b.dataset.action === 'Open project') { markRead(item); return navigate('projects'); }
    if (/^(Mark project complete|Reopen project)$/.test(b.dataset.action)) { // Ryan, 2026-11-04
      const path = item.projectPath || String(item.externalId || '').replace(/^project:/, '');
      const done = b.dataset.action !== 'Reopen project';
      try { await setProjectComplete(path, done); } catch (err) { toast(err.message, 'error'); }
      return;
    }
    await api('/tasks', { text: `${b.dataset.action}: ${item.title}`, priority: item.priority || undefined, section: sectionOf(item) });
    toast(`Task added: ${b.dataset.action}`);
    markRead(item);
  });
}

function feedItemHtml(i, isNew) {
  const cat = CATEGORY[i.category] || CATEGORY.INSIGHT;
  // Calendar cards already show their time in the quote, so their "Starts …" line isn't repeated (Ryan, 2026-11-04).
  const deadline = i.deadline && !/^Starts /.test(i.deadline) ? i.deadline : '';
  const meta = [i.priority ? `<span class="pri-${i.priority}">${esc(i.priority)} Priority</span>` : '', deadline ? `<span class="dead">${esc(deadline)}</span>` : ''].filter(Boolean).join(' · ');
  const calColor = CAL_MARK[i.source] || i.category === 'MEETING' ? '#00e5ff' : cat.c; // calendar cards use the Calendar hub's aqua (Ryan, 2026-11-02)
  return `<div class="activity ${isNew ? 'new' : ''} ${i.removed ? 'removed' : ''} ${i.completed ? 'completed' : ''} ${i.pinned ? 'pinned' : ''}" data-id="${i.id}" style="--c:${calColor}">
    <div class="agent-icon">${icon(cat.icon)}</div>
    <div class="activity-details">
      <div class="a-head">${sourceChip(i)}</div>
      <div class="a-title">${esc(i.title)}</div>
      <div class="a-cat">${i.unread && !i.removed && !i.completed ? '<span class="unread-dot"></span>' : ''}${i.removed ? '<span class="pill removed-pill">Removed</span>' : ''}${i.completed ? `<span class="pill done-pill">${icon('check')}Completed</span>` : ''}${typePill(i) || `<span class="pill" style="--pill:${cat.pill};--pill-text:${cat.text}">${esc(i.category)}</span>`}<button class="dismiss-btn" data-dismiss="${i.id}" title="Clear from the feed" aria-label="Clear this card from the feed">${icon('x')}</button>${isEventCard(i) ? `<button class="more-btn" data-more title="Edit or delete this event" aria-label="Event options" aria-haspopup="menu">${icon('more-vertical')}</button>` : ''}</div>
      ${i.quote ? `<div class="a-quote">${esc(i.quote)}</div>` : ''}
      ${i.description ? `<div class="a-desc">${esc(i.description)}</div>` : ''}
      ${i.summary && !/^Coming up\b/.test(i.summary) ? `<div class="a-summary">${esc(i.summary)}</div>` : ''}
      ${meta ? `<div class="a-meta">${meta}</div>` : ''}
      ${typeof i.progress === 'number' ? `<div class="progress"><div class="track"><div class="bar" style="width:${i.progress}%"></div></div><span>${i.progress}%</span></div>` : ''}
      <div class="a-foot">${i.actions && i.actions.length && !i.removed ? `<div class="a-actions">${i.actions.map((a) => `<button data-action="${esc(a)}" class="${/task/i.test(a) ? 'task-btn' : ''}">${/task/i.test(a) ? icon('plus') : ''}${esc(a)}</button>`).join('')}</div>` : ''}<button class="pin-btn ${i.pinned ? 'on' : ''}" data-pin title="${i.pinned ? 'Unpin' : 'Pin to the top of the feed'}" aria-label="${i.pinned ? 'Unpin card' : 'Pin card'}" aria-pressed="${!!i.pinned}">${i.pinned ? '<span>Pinned</span>' : ''}${icon('pin')}</button></div>
    </div></div>`;
}

// "Projects" in the feed's filter (Ryan, 2026-11-04): project cards, milestone reminders and reminders for project tasks.
const isProjectCard = (i) => i.category === 'PROJECT' || i.milestone || /^Projects\//.test(i.taskPath || i.projectPath || '');

// Pinned cards first (most recently pinned on top), then newest first.
const pinFirst = (a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || (a.pinned ? (b.pinnedAt || 0) - (a.pinnedAt || 0) : 0) || b.ts - a.ts;

function renderFeed(animateFirst) {
  if (S.sourceView) return renderSourceView();
  const list = $('#feed-list');
  const items = S.feed.filter((i) => (S.source === 'all' || i.source === S.source || (S.source === 'projects' && isProjectCard(i))) && (S.category === 'all' || i.category === S.category)).sort(pinFirst);
  const cfgNow = S.state.config, srcConn = S.source !== 'all' ? (cfgNow.connections[cfgNow.profile] || {})[S.source] : null;
  if (!items.length && srcConn && srcConn.mode === 'claude') { showSource(S.source); return; } // shows how to sync it from Claude
  if (!items.length && srcConn && srcConn.mode === 'live' && S.source === 'slack' && !(srcConn.fields && srcConn.fields.channels && srcConn.fields.channels.length)) {
    list.innerHTML = `<div class="feed-empty">${icon('hash')}<br>Slack is connected, but no channels are picked yet.<br>Open the Slack card on <a href="#connections" data-go>MCP Connections</a> and tick the channels to follow.</div>`;
    return;
  }
  if (!items.length) {
    list.innerHTML = `<div class="feed-empty">${icon('plug')}<br>No activity yet.<br>Connect sources on the <a href="#connections" data-go>MCP Connections</a> page and notifications will stream in here.</div>`;
    const go = list.querySelector('[data-go]'); if (go) go.onclick = (e) => { e.preventDefault(); navigate('connections'); };
    return;
  }
  list.innerHTML = items.map((i, k) => feedItemHtml(i, animateFirst && k === 0)).join('');
  list.querySelectorAll('.activity[data-id]').forEach((el) => wireCard(el));
  const unread = S.feed.some((i) => i.unread);
  $('#bell-dot').hidden = !unread;
}

// ---------------------------------------------------------------- source view (click a source on the brain map)
async function showSource(id) {
  S.sourceView = id;
  $('#feed').classList.add('open');
  $('#feed-list').innerHTML = '<div class="feed-empty">Loading…</div>';
  if (String(id).startsWith('project:')) S.sourceData = await projectSource(id);
  else try { S.sourceData = await api('/source?id=' + encodeURIComponent(id)); } catch (e) { S.sourceData = { id, name: id, connected: false, error: e.message, events: [], items: [] }; }
  if (S.sourceView === id) { renderSourceView(); $('#feed-list').scrollTop = 0; }
}

// A project node on the brain map shows only that project's card in the feed (Ryan, 2026-11-04).
async function projectSource(id) {
  const path = id.slice('project:'.length);
  let card = S.feed.find((x) => x.externalId === id);
  if (!card) { try { card = (await api('/feed?limit=400')).find((x) => x.externalId === id); } catch { /* offline */ } }
  let name = path.split('/').pop().replace(/\.md$/, '');
  if (!card) {
    // the card was cleared (or the project came from Obsidian): show the project as a card anyway
    try {
      const p = await api('/projects/one?path=' + encodeURIComponent(path)); name = p.name;
      card = { id, ts: Date.now(), source: 'system', sourceName: 'Maestro', category: 'PROJECT', title: p.name, quote: [p.client && `Client: ${p.client}`, (p.start || p.completion) && `${p.start || '?'} → ${p.completion || '?'}`].filter(Boolean).join(' · '),
        description: p.description, summary: [p.nextMilestone && `Next milestone: ${p.nextMilestone.name}`, `${p.tasks.open} open task${p.tasks.open === 1 ? '' : 's'}`].filter(Boolean).join(' · '), progress: p.tasks.total ? p.progress : undefined, completed: p.completed, actions: ['Open project', p.completed ? 'Reopen project' : 'Mark project complete'], unread: false };
    } catch { /* gone */ }
  } else name = card.title.replace(/^New project: /, '');
  return { id, project: true, name, items: card ? [card] : [] };
}
function renderProjectView(d) {
  const list = $('#feed-list');
  list.innerHTML = `<div class="src-head" style="--c:#00f2af"><button class="src-back" id="src-back" title="Back to all activity">${icon('arrow-right')}</button><span class="agent-icon">${icon('folder')}</span><div><b>${esc(d.name)}</b><div><span class="tag live">Project</span></div></div></div>`
    + (d.items.length ? d.items.map((i) => feedItemHtml(i, false)).join('') : `<div class="feed-empty" style="padding:18px">This project is no longer in your vault.</div>`);
  const back = S.sourceBack; // opened from the Projects list: back goes to the list
  list.querySelector('#src-back').onclick = () => { S.sourceBack = null; if (back) showSource(back); else closeSource(); };
  list.querySelectorAll('.activity[data-id]').forEach((el) => wireCard(el));
}

function projectListCard(p) {
  const open = (p.taskList || []).filter((t) => !t.done), done = (p.taskList || []).length - open.length;
  const today = new Date().toISOString().slice(0, 10);
  return `<div class="activity proj-card ${p.completed ? 'completed' : ''}" data-proj="${esc(p.path)}" style="--c:#00f2af" tabindex="0" role="button" aria-label="Open ${esc(p.name)}">
    <div class="agent-icon">${icon('folder')}</div>
    <div class="activity-details">
      <div class="a-title">${esc(p.name)}</div>
      <div class="a-cat"><span class="pill proj-status ${p.progress >= 100 ? 'done' : ''}">${esc(projectStatus(p))}</span></div>
      ${p.client ? `<div class="pc-client">${icon('briefcase')}${esc(p.client)}</div>` : ''}
      ${p.description ? `<div class="a-desc">${esc(p.description)}</div>` : ''}
      <div class="pc-tasks"><div class="pc-sub">Tasks <span>${open.length} open${done ? ` · ${done} done` : ''}</span></div>
        ${open.length ? open.slice(0, 5).map((t) => `<label class="pc-task" title="Tick to mark done"><input type="checkbox" data-tp="${esc(t.path)}" data-tl="${t.line}" aria-label="Mark “${esc(t.text)}” done"><span>${esc(t.text)}</span>${t.due ? `<small class="${t.due < today ? 'late' : ''}">${new Date(t.due + 'T12:00').toLocaleDateString([], { month: 'short', day: 'numeric' })}</small>` : ''}</label>`).join('') + (open.length > 5 ? `<div class="pc-more">+${open.length - 5} more</div>` : '') : `<div class="pc-none">${done ? 'All tasks done.' : 'No tasks yet.'}</div>`}</div>
      ${p.progress != null ? `<div class="progress"><div class="track"><div class="bar" style="width:${p.progress}%"></div></div><span>${p.progress}%</span></div>` : ''}
      <div class="a-foot"><div class="a-actions"><button data-complete="${p.completed ? '0' : '1'}" class="${p.completed ? '' : 'task-btn'}">${icon(p.completed ? 'refresh' : 'check')}${p.completed ? 'Reopen project' : 'Mark project complete'}</button></div></div>
    </div></div>`;
}
// Finish or reopen a project, then refresh whatever is showing it.
async function setProjectComplete(path, done) {
  const p = await api('/projects/complete', { path, done });
  toast(done ? `${p.name} marked complete` : `${p.name} reopened`);
  const card = S.feed.find((x) => x.externalId === 'project:' + path);
  if (card) Object.assign(card, { completed: p.completed, actions: ['Open project', p.completed ? 'Reopen project' : 'Mark project complete'], deadline: p.completed ? '' : card.deadline });
  if (S.sourceView) showSource(S.sourceView); else renderFeed(false);
  return p;
}
async function fillProjectList(el, hubId) {
  let list = [];
  try { list = await api('/projects'); } catch (e) { el.innerHTML = `<div class="feed-empty" style="padding:18px">${esc(e.message)}</div>`; return; }
  if (S.sourceView !== hubId) return;
  el.innerHTML = list.length ? list.map(projectListCard).join('') : `<div class="feed-empty" style="padding:18px">No projects yet. Create one on the <a href="#projects" data-go>Projects</a> page.</div>`;
  const go = el.querySelector('[data-go]'); if (go) go.onclick = (e) => { e.preventDefault(); navigate('projects'); };
  el.querySelectorAll('[data-proj]').forEach((c) => {
    // tick a task or finish the project right on the card (Ryan, 2026-11-04)
    c.querySelectorAll('.pc-task').forEach((l) => (l.onclick = (e) => e.stopPropagation()));
    c.querySelectorAll('[data-tp]').forEach((x) => (x.onchange = async () => {
      x.disabled = true;
      try { await api('/tasks/toggle', { path: x.dataset.tp, line: Number(x.dataset.tl) }); toast('Task done'); } catch (err) { toast(err.message, 'error'); }
      fillProjectList(el, hubId);
    }));
    const cb = c.querySelector('[data-complete]');
    if (cb) cb.onclick = async (e) => { e.stopPropagation(); try { await setProjectComplete(c.dataset.proj, cb.dataset.complete === '1'); } catch (err) { toast(err.message, 'error'); } };
    const open = () => { S.sourceBack = hubId; showSource('project:' + c.dataset.proj); };
    c.onclick = open; c.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } };
  });
}

function closeSource() { S.sourceBack = null; S.sourceView = null; S.sourceData = null; if (brain) brain.selectedSource = null; renderFeed(false); }

function dayLabel(d) {
  const t = new Date(); t.setHours(0, 0, 0, 0);
  const x = new Date(d); x.setHours(0, 0, 0, 0);
  const diff = Math.round((x - t) / 86400000);
  return diff === 0 ? 'Today' : diff === 1 ? 'Tomorrow' : new Date(d).toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' });
}

function renderSourceView() {
  const d = S.sourceData; if (!d) return;
  if (d.project) return renderProjectView(d);
  if (d.hub) return renderHubView(d);
  const list = $('#feed-list');
  const conn = S.state.connectors.find((c) => c.id === d.id) || { name: d.name, color: '#00e5ff', icon: 'plug' };
  const mode = !d.connected ? '<span class="tag off">Not connected</span>' : d.error ? '<span class="tag err">● Error</span>' : d.mode === 'live' ? '<span class="tag live">● Live</span>' : d.mode === 'claude' ? '<span class="tag live">● Live in Claude</span>' : '<span class="tag demo">● Demo data</span>';
  let html = `<div class="src-head" style="--c:${conn.color}"><button class="src-back" id="src-back" title="Back to all activity">${icon('arrow-right')}</button><span class="agent-icon">${icon(conn.icon)}</span><div><b>${esc(conn.name)}</b><div>${mode}</div></div></div>`;
  // Not connected or failing: show it as a notification with a button to fix it.
  if (!d.connected || d.error) {
    html += `<div class="activity notice ${d.error ? 'err' : ''}" style="--c:${d.error ? '#ff4d6d' : '#3d8bff'}">
      <div class="agent-icon">${icon('plug')}</div>
      <div class="activity-details">
        <span class="a-time">just now · Maestro</span>
        <div class="a-title">${d.error ? `${esc(conn.name)} connection failed` : `${esc(conn.name)} isn't connected`}</div>
        <div class="a-cat"><span class="pill" style="--pill:${d.error ? '#4a0f1c' : '#0d2a55'};--pill-text:${d.error ? '#ff8095' : '#8bb8ff'}">CONNECTION</span></div>
        <div class="a-quote">${d.error ? esc(d.error) : d.kind === 'calendar' ? `Connect ${esc(conn.name)} to see your schedule here.` : `Connect ${esc(conn.name)} to stream its notifications into your feed.`}</div>
        <div class="a-actions"><button class="btn small connect" id="src-connect">${icon('plug')} Make Connection</button></div>
      </div></div>`;
  }
  // Calendars show their month view only from the Calendar hub on the brain (Ryan, 2026-11-02).
  const items = d.connected ? S.feed.filter((i) => i.source === d.id) : [];
  if (d.connected) {
    html += `<div class="section-title" style="margin:14px 4px 6px">Recent activity</div>`;
    if (!items.length && d.mode === 'claude') {
      const canLive = conn.live && conn.live.includes('dashboard');
      html += `<div class="activity notice" style="--c:#8b5cff">
        <div class="agent-icon">${icon('sparkles')}</div>
        <div class="activity-details">
          <span class="a-time">Maestro</span>
          <div class="a-title">Ask Claude to bring ${esc(conn.name)} in</div>
          <div class="a-quote">Claude Desktop's ${esc(conn.name)} connector only works inside Claude, so Maestro can't read it by itself. In Claude Desktop, click <b>+</b> → <b>Maestro</b> → <b>Sync my Claude connectors into Maestro</b>, or just type the request below. New items land here a few seconds later.${canLive ? ` To stream ${esc(conn.name)} automatically instead, connect it live with a token.` : ''}</div>
          <div class="a-actions"><button class="btn small" id="src-copy">${icon('copy')} Copy request for Claude</button>${canLive ? `<button class="btn small connect" id="src-connect">${icon('plug')} Connect live instead</button>` : ''}</div>
        </div></div>`;
    } else html += items.length ? items.map((i) => feedItemHtml(i, false)).join('') : `<div class="feed-empty" style="padding:18px">No recent activity from ${esc(conn.name)}.</div>`;
  }
  list.innerHTML = html;
  list.querySelector('#src-back').onclick = closeSource;
  const mk = list.querySelector('#src-connect');
  if (mk) mk.onclick = () => {
    const c = S.state.connectors.find((x) => x.id === d.id);
    connectModal(c, S.state.config.profile, async () => { await afterChange({ graph: false }); showSource(d.id); });
  };
  const cp = list.querySelector('#src-copy');
  if (cp) cp.onclick = async () => { try { await navigator.clipboard.writeText(`Sync my ${conn.name} into Maestro: read my latest ${conn.name} activity with your connector and add it with the Maestro add_feed_items tool.`); toast('Copied. Paste it into Claude Desktop.'); } catch { toast('Copy failed. Use the Maestro prompt in Claude Desktop instead.', 'error'); } };
  list.querySelectorAll('[data-note]').forEach((el) => el.onclick = () => openNote(el.dataset.note));
  list.querySelectorAll('.activity[data-id]').forEach((el) => wireCard(el));
}

// A hub (Email, Calendar, Messages, Calls, Projects): everything from its connected sources in one place.
function renderHubView(d) {
  const list = $('#feed-list');
  const on = d.members.filter((m) => m.connected), bad = d.members.filter((m) => m.error);
  let html = `<div class="src-head" style="--c:${d.color}"><button class="src-back" id="src-back" title="Back to all activity">${icon('arrow-right')}</button><span class="agent-icon">${icon({ calendar: 'calendar-days', projects: 'folder' }[d.kind] || { 'hub:email': 'mail', 'hub:messages': 'message-square', 'hub:calls': 'phone' }[d.id] || 'plug')}</span><div><b>${esc(d.name)}</b><div class="hub-chips">${d.members.map((m) => `<button class="hub-chip ${m.connected ? (m.error ? 'err' : 'on') : ''}" data-member="${m.id}" title="${m.connected ? 'Manage' : 'Connect'} ${esc(m.name)}">${m.connected ? '● ' : '+ '}${esc(m.name.replace(/ \(.*\)/, '').replace(' / Microsoft 365', ''))}</button>`).join('')}</div></div></div>`;
  const notice = (title, text, err, member) => `<div class="activity notice ${err ? 'err' : ''}" style="--c:${err ? '#ff4d6d' : '#3d8bff'}">
      <div class="agent-icon">${icon('plug')}</div><div class="activity-details">
      <span class="a-time">just now · Maestro</span><div class="a-title">${title}</div>
      <div class="a-cat"><span class="pill" style="--pill:${err ? '#4a0f1c' : '#0d2a55'};--pill-text:${err ? '#ff8095' : '#8bb8ff'}">CONNECTION</span></div>
      <div class="a-quote">${text}</div>
      <div class="a-actions"><button class="btn small connect" data-make="${member || ''}">${icon('plug')} Make Connection</button></div></div></div>`;
  if (!on.length && d.kind !== 'projects') html += notice(`No ${esc(d.name.toLowerCase())} connected yet`, `Connect ${d.members.map((m) => esc(m.name)).join(', ').replace(/, ([^,]*)$/, ' or $1')} to ${d.kind === 'calendar' ? 'see your schedule here' : 'stream it into your feed'}.`, false, '');
  for (const m of bad) html += notice(`${esc(m.name)} connection failed`, esc(m.error), true, m.id);
  if (d.kind === 'calendar' && on.length) html += `<div id="hub-month"></div>`; // month calendar, filled in below
  // The Projects hub lists your projects as cards (Ryan, 2026-11-04): name, client, 2 lines of description, tasks
  // and how complete it is. Clicking one shows that project's own card.
  if (d.kind === 'projects') html += `<div id="hub-projects"><div class="feed-empty" style="padding:18px">Loading projects…</div></div>`;
  const ids = new Set(on.map((m) => m.id));
  const items = S.feed.filter((i) => d.categories.includes(i.category) && (ids.has(i.source) || (d.kind === 'projects' && i.source === 'system')));
  if (on.length && d.kind !== 'projects') {
    html += `<div class="section-title" style="margin:14px 4px 6px">Recent activity</div>`;
    html += items.length ? items.map((i) => feedItemHtml(i, false)).join('') : `<div class="feed-empty" style="padding:18px">Nothing new.</div>`;
  }
  list.innerHTML = html;
  list.querySelector('#src-back').onclick = closeSource;
  const hp = list.querySelector('#hub-projects');
  if (hp) fillProjectList(hp, d.id);
  const hm = list.querySelector('#hub-month');
  if (hm) { const ids = new Set(on.map((m) => m.id)); monthCalendar(hm, { filter: (e) => ids.has(e.source) || e.source === 'maestro' || (e.created && !e.calendarFor), ask: (t) => ask(t) }); }
  const prof = S.state.config.profile;
  const openConnect = (mid) => {
    const c = S.state.connectors.find((x) => x.id === mid);
    connectModal(c, prof, async () => { await afterChange({ graph: false }); showSource(d.id); });
  };
  list.querySelectorAll('[data-member]').forEach((b) => b.onclick = () => openConnect(b.dataset.member));
  list.querySelectorAll('[data-make]').forEach((b) => b.onclick = () => b.dataset.make ? openConnect(b.dataset.make) : pickConnection(d, openConnect));
  list.querySelectorAll('[data-note]').forEach((el) => el.onclick = () => openNote(el.dataset.note));
  list.querySelectorAll('.activity[data-id]').forEach((el) => wireCard(el));
}

// "Make Connection" on a hub: pick which service to connect.
function pickConnection(d, openConnect) {
  const m = modal(`${modalHead(`Connect ${esc(d.name.toLowerCase())}`, 'Choose a service. You can connect more than one.')}
    ${d.members.map((x) => { const c = S.state.connectors.find((y) => y.id === x.id); return `<button class="choice" data-pick="${x.id}"><span class="agent-icon" style="--c:${c.color};width:30px;height:30px;font-size:16px">${icon(c.icon)}</span><div><b>${esc(c.name)}</b><span>${esc(c.description)}</span></div>${x.connected ? '<span class="tag live" style="margin-left:auto">● Connected</span>' : ''}</button>`; }).join('')}`, {
    onMount: (el, close) => el.querySelectorAll('[data-pick]').forEach((b) => b.onclick = () => { close(); openConnect(b.dataset.pick); }),
  });
  return m;
}

async function markRead(item) {
  if (!item.unread) return;
  item.unread = false;
  api('/feed/read', { id: item.id }).catch(() => {});
  renderFeed(false);
}

// Web links in an event description open in a new tab. Works on already-escaped text.
const linkify = (h) => h.replace(/https?:\/\/[^\s<]+[^\s<.,;:)!?'"]/g, (u) => `<a href="${u}" target="_blank" rel="noopener">${u}</a>`);

// "Create Task" on an event card (Ryan, 2026-11-02): say or type a note about the event, its action items and
// deadlines; it all goes on Maestro's main task list (the note as the task, action items as sub-tasks).
function eventTaskForm(item, { prompt = '', viaVoice = false } = {}) {
  const title = item.title.replace(/^(New( recurring event)?|Moved|Cancelled): /, '');
  const isEvent = !!(item.eventKey || item.category === 'MEETING');
  const section = isEvent ? 'calendar' : sectionOf(item);
  const SRc = window.SpeechRecognition || window.webkitSpeechRecognition;
  const micWasOn = !!(voice && voice.active);
  const listenAfter = micWasOn || (viaVoice && !!voice); // asked by voice: the note is taken by voice too
  if (micWasOn) { voice.stop(); voice.stopSpeaking(); } // the chat mic would send the dictation as a message
  let rec = null, target = null, base = '';
  const stopDictation = () => { if (rec) { try { rec.stop(); } catch { /* already stopped */ } } rec = null; document.querySelectorAll('.dict-btn.on').forEach((b) => b.classList.remove('on')); };
  const dictate = (btn, field) => {
    if (rec && target === field) return stopDictation();
    stopDictation();
    if (!SRc) return toast('Voice input needs Chrome or Edge. You can still type.', 'error');
    target = field; base = field.value ? field.value.replace(/\s*$/, ' ') : '';
    rec = new SRc(); rec.lang = (S.state.config.voice && S.state.config.voice.lang) || 'en-US'; rec.continuous = true; rec.interimResults = true;
    let done = '';
    rec.onresult = (e) => {
      let interim = '';
      for (let i = e.resultIndex; i < e.results.length; i++) { const t = e.results[i][0].transcript; if (e.results[i].isFinal) done += t.trim() + (field.id === 'et-items' ? '\n' : ' '); else interim += t; }
      field.value = base + done + interim;
    };
    rec.onend = () => { if (rec) { btn.classList.remove('on'); rec = null; } };
    try { rec.start(); btn.classList.add('on'); } catch { rec = null; }
  };
  const micBtn = (id, label) => `<button type="button" class="dict-btn" data-dict="${id}" title="Say it" aria-label="${label}">${icon('mic')}</button>`;
  modal(`${modalHead('Create Task', esc(title))}
    <p class="et-ask">Say or type a note about this ${isEvent ? 'event' : 'item'}, any action items, and when they need to be done.</p>
    <div class="field"><label for="et-note">Note</label><div class="dict-wrap"><textarea class="input et-text" id="et-note" rows="3" placeholder="e.g. Follow up with the speakers about sharing the recording"></textarea>${micBtn('et-note', 'Dictate the note')}</div></div>
    <div class="field"><label for="et-items">Action items</label><div class="dict-wrap"><textarea class="input et-text" id="et-items" rows="4" placeholder="One per line, e.g.&#10;Send the slides to attendees by Friday&#10;Book the room for next month"></textarea>${micBtn('et-items', 'Dictate action items')}</div><span class="help">Deadlines you say, like “by Friday” or “due November 12”, are picked up for each item. The due date, time and reminders below apply to the rest.</span></div>
    ${dueFields('et')}
    <div class="field et-pri"><label for="et-pri">Priority</label><select class="input" id="et-pri"><option value="">None</option><option>High</option><option>Medium</option><option>Low</option></select></div>
    <div class="modal-foot"><button class="btn ghost" data-close>Cancel</button><button class="btn primary" id="et-save">${icon('plus')} Add to tasks</button></div>`, {
    onClose: () => { stopDictation(); if (micWasOn && !voice.active) toggleMic(); },
    onMount: (el, close) => {
      el.querySelectorAll('[data-dict]').forEach((b) => (b.onclick = () => dictate(b, el.querySelector('#' + b.dataset.dict))));
      const readDue = wireDueFields(el, 'et');
      const note = el.querySelector('#et-note');
      setTimeout(() => note.focus(), 50);
      // Maestro asks out loud only when you started the task by voice; then it listens for the note.
      if (viaVoice && S.state.config.voice && S.state.config.voice.speakReplies && voice) { // only out loud when you asked by voice (Ryan, 2026-11-02)
        voice.speak(prompt || `What's your note about ${title}? Add any action items and when they're due.`, { voiceName: S.state.config.voice.voiceName, gender: S.state.config.voice.gender, rate: S.state.config.voice.rate, pause: S.state.config.voice.pause, onEnd: () => { if (listenAfter && document.body.contains(note) && !rec) dictate(el.querySelector('[data-dict=et-note]'), note); } });
      }
      el.querySelector('#et-save').onclick = async () => {
        stopDictation();
        const body = { section: section || 'calendar', event: title, note: note.value.trim(), items: el.querySelector('#et-items').value, priority: el.querySelector('#et-pri').value, ...readDue() };
        if (!body.note && !body.items.trim()) { note.focus(); return toast('Add a note or an action item first', 'error'); }
        try {
          const r = await api('/tasks/event', body);
          toast(`${r.count} task${r.count === 1 ? '' : 's'} added${r.due ? ' · due ' + new Date(r.due + 'T12:00').toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' }) : ''}`);
          close();
        } catch (e) { toast(e.message || 'Could not add the task', 'error'); }
      };
    },
  });
}

// Event details lightbox (Ryan, 2026-11-06): the event's facts stacked one per row (when, where, links, calendar),
// then the description laid out as paragraphs and bullet lists, instead of one long block.
const shortUrl = (u) => { try { const x = new URL(u); const path = x.pathname.replace(/\/$/, ''); return x.host.replace(/^www\./, '') + (path.length > 1 ? (path.length > 24 ? path.slice(0, 22) + '…' : path) : ''); } catch { return u; } };
function linkKind(u) {
  if (/zoom\.us|meet\.google|teams\.(microsoft|live)|webex|whereby|gotomeet/i.test(u)) return ['video', 'Join video call'];
  if (/lu\.ma|luma\.com|eventbrite|meetup\.com|tito\.io|ticket/i.test(u)) return ['ticket', 'Tickets'];
  if (/maps\.(google|apple)|goo\.gl\/maps/i.test(u)) return ['map-pin', 'Map'];
  return ['link', shortUrl(u)];
}
function descHtml(text) {
  const link = (h) => h.replace(/https?:\/\/[^\s<]+[^\s<.,;:)!?'"]/g, (u) => `<a href="${u}" target="_blank" rel="noopener" title="${u}">${esc(shortUrl(u.replace(/&amp;/g, '&')))}</a>`);
  const out = []; let list = null, para = [];
  const flushPara = () => { if (para.length) out.push(`<p>${para.join('<br>')}</p>`); para = []; };
  const flushList = () => { if (list) out.push(`<ul>${list.map((x) => `<li>${x}</li>`).join('')}</ul>`); list = null; };
  for (const raw of String(text).split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) { flushPara(); flushList(); continue; }
    const bullet = line.match(/^(?:[-*•▪◦]|\d+[.)])\s+(.*)$/);
    const h = link(esc(bullet ? bullet[1] : line)).replace(/^([A-Z][\w ?'’&/-]{1,24}):(\s|$)/, '<b>$1:</b>$2');
    if (bullet) { flushPara(); (list = list || []).push(h); } else { flushList(); para.push(h); }
  }
  flushPara(); flushList();
  return out.join('');
}
function eventDetailHtml(item) {
  const start = item.eventStart ? new Date(item.eventStart) : null, end = item.eventEnd ? new Date(item.eventEnd) : null;
  const title = item.eventTitle || item.title.replace(/^(New( recurring event)?|Updated|Moved|Time changed|Cancelled|Reminder|In [^:]+|Starting now|Happening now): /, '');
  const rows = [];
  if (start && !isNaN(start)) {
    const day = start.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', year: start.getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined });
    const t = (d) => d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    const mins = end && !isNaN(end) ? Math.round((end - start) / 60000) : 0;
    const len = mins >= 1440 ? '' : mins >= 60 ? ` (${Math.floor(mins / 60)} h${mins % 60 ? ` ${mins % 60} min` : ''})` : mins ? ` (${mins} min)` : '';
    rows.push(['calendar-days', 'When', `${esc(day)}<small>${esc(t(start))}${end && !isNaN(end) && mins < 1440 ? ` – ${esc(t(end))}` : ''}${esc(len)}</small>`]);
  } else if (item.quote) rows.push(['calendar-days', 'When', esc(item.quote)]);
  const loc = item.eventLocation || '';
  if (loc && !/^https?:/i.test(loc)) rows.push(['map-pin', 'Where', `${esc(loc)}<small><a href="https://maps.google.com/?q=${encodeURIComponent(loc)}" target="_blank" rel="noopener">Open in Maps</a></small>`]);
  const urls = [...new Set(`${loc} ${item.description || ''}`.match(/https?:\/\/[^\s<>"']+[^\s<>"'.,;:)!?]/g) || [])].slice(0, 6);
  if (urls.length) rows.push(['link', 'Links', `<div class="evd-links">${urls.map((u) => { const [ic, label] = linkKind(u); return `<a class="evd-link" href="${esc(u)}" target="_blank" rel="noopener" title="${esc(u)}">${icon(ic === 'ticket' ? 'tag' : ic)}${esc(label)}</a>`; }).join('')}</div>`]);
  const cal = [item.sourceName, item.calendarName].filter(Boolean).join(' · ');
  if (cal) rows.push(['layers', 'Calendar', esc(cal)]);
  const status = [item.removed ? 'Removed' : '', item.summary && !/^Coming up\b/.test(item.summary) ? item.summary : '', item.priority ? `${item.priority} priority` : ''].filter(Boolean).join(' · ');
  if (status) rows.push(['info', 'Status', esc(status)]);
  return { title, html: `<div class="evd-rows">${rows.map(([ic, k, v]) => `<div class="evd-row"><span class="evd-ic">${icon(ic)}</span><div><span class="evd-k">${k}</span><div class="evd-v">${v}</div></div></div>`).join('')}</div>
    ${item.description ? `<div class="evd-about"><div class="evd-k">About this event</div><div class="evd-desc">${descHtml(item.description)}</div></div>` : ''}` };
}

function openFeedItem(item) {
  markRead(item);
  const cat = CATEGORY[item.category] || CATEGORY.INSIGHT;
  if (item.category === 'MEETING' && (item.eventStart || item.eventKey || item.description)) return openEventItem(item);
  modal(`${modalHead(esc(item.title), `${esc(item.sourceName)} · ${timeAgo(item.ts)} · ${esc(item.category)}`)}
    ${item.quote ? `<blockquote class="md" style="border-left:3px solid ${cat.c};padding:8px 12px;background:rgba(0,45,76,.35);margin:0 0 10px">${esc(item.quote)}</blockquote>` : ''}
    ${item.description ? `<div class="ev-desc">${linkify(esc(item.description)).replace(/\n/g, '<br>')}</div>` : ''}
    ${item.summary ? `<p>${esc(item.summary)}</p>` : ''}
    <p class="meta" style="color:var(--muted)">${[item.priority && item.priority + ' priority', item.deadline].filter(Boolean).map(esc).join(' · ')}</p>
    ${item.notePath ? `<p><a href="#" data-note>Open ${esc(item.notePath)}</a></p>` : ''}
    <div class="modal-foot">
      ${item.eventKey || item.category === 'MEETING' ? `<button class="btn ghost" data-event-task>${icon('clipboard-check')} Create Task</button>` : `<button class="btn ghost" data-task>${icon('plus')} Make it a task</button>`}
      <button class="btn primary" data-ask>${icon('sparkles')} Ask ${esc(S.state.config.assistantName)} about this</button>
    </div>`, {
    onMount: (el, close) => {
      el.querySelector('[data-ask]').onclick = () => { close(); if (item.eventKey && !item.removed) return ask(`Tell me about ${item.title.replace(/^(New( recurring event)?|Moved|Cancelled): /, '')}`); ask(`Help me with this ${item.category.toLowerCase()} from ${item.sourceName}: "${item.title}". ${item.quote || ''} What should I do?`); };
      const mt = el.querySelector('[data-task]'); if (mt) mt.onclick = async () => { await api('/tasks', { text: item.title, priority: item.priority || undefined, section: sectionOf(item) }); toast('Task added'); close(); };
      const et = el.querySelector('[data-event-task]'); if (et) et.onclick = () => { close(); eventTaskForm(item); };
      const n = el.querySelector('[data-note]'); if (n) n.onclick = (e) => { e.preventDefault(); close(); openNote(item.notePath); };
    },
  });
}

function openEventItem(item) {
  const d = eventDetailHtml(item);
  const label = item.title !== d.title ? item.title.split(':')[0] : '';
  modal(`<div class="modal-head evd-head"><div style="flex:1;min-width:0"><div class="evd-tags">${typePill(item) || '<span class="pill">MEETING</span>'}${label ? `<span class="evd-flag">${esc(label)}</span>` : ''}</div><h3>${esc(d.title)}</h3></div><button class="icon-btn" data-close aria-label="Close">${icon('x')}</button></div>
    ${d.html}
    <div class="modal-foot evd-foot">
      ${!item.removed ? `<button class="btn ghost" data-ev-edit>${icon('pencil')} Edit</button>` : ''}
      <button class="btn ghost" data-event-task>${icon('clipboard-check')} Create Task</button>
      <button class="btn primary" data-ask>${icon('sparkles')} Ask ${esc(S.state.config.assistantName)}</button>
    </div>`, {
    onMount: (el, close) => {
      el.querySelector('[data-ask]').onclick = () => { close(); ask(`Tell me about ${d.title}`); };
      el.querySelector('[data-event-task]').onclick = () => { close(); eventTaskForm(item); };
      const ed = el.querySelector('[data-ev-edit]'); if (ed) ed.onclick = () => { close(); editEvent(item); };
      el.querySelectorAll('.evd-pill-type, [data-type]').forEach((b) => (b.onclick = (e) => { e.stopPropagation(); typeMenu(b, item); }));
    },
  });
}

function visibleNow(item) {
  const cfg = S.state.config;
  if (item.profile !== cfg.profile && item.profile !== 'both') return false;
  if (item.pack && !cfg.packs.includes(item.pack)) return false;
  if (item.source === 'system') return true;
  return !!(cfg.connections[cfg.profile] || {})[item.source];
}

// After Maestro restarts with a new version, open dashboards reload so page and server match.
let serverBuild = null;
async function checkBuild() {
  try { const v = await api('/version'); if (serverBuild && v.build !== serverBuild) location.reload(); serverBuild = v.build; } catch { /* older server: no /version */ }
}
function connectStream() {
  const es = new EventSource('/api/stream');
  es.addEventListener('open', checkBuild);
  es.addEventListener('feed', (e) => {
    const item = JSON.parse(e.data);
    if (!visibleNow(item)) return;
    // Task reminders also pop up as a desktop notification when the browser allows it (Ryan, 2026-11-02).
    if ((item.reminder || item.alert) && 'Notification' in window && Notification.permission === 'granted') {
      try { const n = new Notification(item.title, { body: [item.deadline, item.quote].filter(Boolean).join(' · '), tag: item.externalId || item.id }); n.onclick = () => { window.focus(); if (item.alert) openFeedItem(item); else navigate('tasks'); }; } catch { /* not allowed here */ }
    }
    mergeFeed([item]);
    renderFeed(true);
    const cat = CATEGORY[item.category] || CATEGORY.INSIGHT;
    if (brain) brain.pulseSource(item.source, cat.c);
    if (item.notePath) loadGraph();
  });
  es.addEventListener('feed-remove', (e) => { const { id } = JSON.parse(e.data); if (S.feed.some((x) => x.id === id)) { S.feed = S.feed.filter((x) => x.id !== id); renderFeed(false); } });
  es.addEventListener('feed-update', (e) => { // e.g. a removed calendar event: its cards turn grey
    const item = JSON.parse(e.data);
    if (!S.feed.some((x) => x.id === item.id)) return;
    mergeFeed([item]);
    if (S.sourceView && S.sourceData) { S.sourceData.items = (S.sourceData.items || []).map((x) => (x.id === item.id ? item : x)); }
    renderFeed(false);
  });
  es.addEventListener('profile', () => afterChange());
}

// header + feed controls
$('#bell').onclick = async () => {
  await api('/feed/read-all', {});
  S.feed.forEach((i) => { i.unread = false; });
  renderFeed(false);
  $('#feed').classList.add('open');
  toast('All caught up');
};
$('#prefs').onclick = () => navigate('settings');
$('#feed-toggle').onclick = () => $('#feed').classList.toggle('open');
$('#feed-all').onclick = () => { S.sourceView = null; S.source = 'all'; S.category = 'all'; fillSourceFilter(); renderFeed(false); $('#feed-list').scrollTop = 0; };
$('#live-toggle').onclick = async () => {
  S.livePaused = !S.livePaused;
  await api('/settings', { demo: { liveFeed: !S.livePaused } });
  renderShell();
  toast(S.livePaused ? 'Live demo feed paused' : 'Live demo feed resumed');
};
$('#cat-filter').onclick = () => {
  const cats = ['all', ...Object.keys(CATEGORY)];
  modal(`${modalHead('Filter by category')}<div class="grid" style="grid-template-columns:repeat(2,1fr)">${cats.map((c) => `<button class="choice ${S.category === c ? 'on' : ''}" data-c="${c}">${icon(c === 'all' ? 'layout-grid' : CATEGORY[c].icon)}<div><b>${c === 'all' ? 'Everything' : c}</b></div></button>`).join('')}</div>`, {
    onMount: (el, close) => el.querySelectorAll('[data-c]').forEach((b) => b.onclick = () => { S.category = b.dataset.c; renderFeed(false); close(); }),
  });
};

boot().catch((e) => { document.body.innerHTML = `<pre style="padding:40px;color:#ff6b81">Maestro failed to start: ${esc(e.message)}\n\nIs the server running? Start it with: npm start</pre>`; });
