// Maestro configuration: one JSON file in ./data that every part of the brain shares
// (dashboard server, Claude Desktop MCP server, CLI).
const fs = require('fs');
const os = require('os');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const DATA_DIR = process.env.MAESTRO_DATA || path.join(ROOT, 'data');
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
// Settings are also kept in the knowledge base (<vault>/.maestro/settings.json, hidden from Obsidian) and in
// ~/.maestro/settings.json, so a fresh download or a new folder picks up your connections instead of starting over.
const HOME_DIR = process.env.MAESTRO_HOME || path.join(os.homedir(), '.maestro');
const PERSIST = ['user', 'assistantName', 'profile', 'llm', 'voice', 'connections', 'packs', 'workflows', 'demo', 'dataMode', 'onboarded', 'knowledge', 'vaultPath', 'port'];

const FOUNDATION = ['gmail', 'outlook', 'email', 'icalendar', 'gcal', 'calendly', 'slack', 'twilio_sms', 'whatsapp', 'twilio_calls', 'google_meet', 'teams', 'zoom'];

function defaultConfig() {
  // Everything starts connected in demo mode so the brain works the moment it is installed.
  const demo = (ids) => Object.fromEntries(ids.map((id) => [id, { mode: 'demo', connectedAt: Date.now() }]));
  return {
    version: 1,
    user: { name: 'Ryan', role: 'Product Manager', timezone: Intl.DateTimeFormat().resolvedOptions().timeZone },
    assistantName: 'Maestro',
    profile: 'business',
    vaultPath: path.join(ROOT, 'vault'),
    llm: {
      provider: 'demo', // demo | anthropic | openai | gemini | compatible
      anthropic: { apiKey: '', model: 'claude-opus-5-5' },
      openai: { apiKey: '', model: 'gpt-5' },
      gemini: { apiKey: '', model: 'gemini-2.5-flash' },
      // Any OpenAI-compatible endpoint: Ollama (Hermes 3/4), LM Studio, OpenRouter, Nous Portal...
      compatible: { baseUrl: 'http://localhost:11434/v1', apiKey: '', model: 'hermes3', label: 'Hermes (Ollama)' },
    },
    voice: { speakReplies: true, handsFree: false, voiceName: '', gender: 'male', rate: 0.92, pause: 750, lang: 'en-US' },
    connections: {
      business: demo(['outlook', 'email', 'gcal', 'slack', 'twilio_calls', 'icalendar']),
      personal: demo(['gmail', 'icalendar', 'twilio_sms', 'twilio_calls']),
    },
    packs: [],
    workflows: {
      morning_brief: { enabled: true, time: '08:00' },
      meeting_prep: { enabled: true, minutesBefore: 15 },
      inbox_triage: { enabled: true, everyMinutes: 60 },
      end_of_day: { enabled: false, time: '17:30' },
    },
    demo: { liveFeed: true, intervalSeconds: 35 },
    // How long before a deadline Maestro reminds you (Ryan, 2026-11-04). tasks: for tasks without their own reminders
    // (empty = the day before and the day of); milestones: for project milestones and completion dates.
    reminders: { tasks: [], milestones: ['1w', '1d'] },
    port: 4141,
    onboarded: false,
    // 'demo' fills the brain with sample data; 'real' starts empty and only shows what the user connects.
    dataMode: 'demo',
    // Where the brain's knowledge lives. connected stays false until the user picks a source on first run.
    knowledge: { type: 'obsidian', connected: false },
  };
}

function deepMerge(base, extra) {
  if (Array.isArray(base) || typeof base !== 'object' || base === null) return extra === undefined ? base : extra;
  const out = { ...base };
  for (const [k, v] of Object.entries(extra || {})) {
    out[k] = v && typeof v === 'object' && !Array.isArray(v) && typeof base[k] === 'object' && base[k] !== null && !Array.isArray(base[k])
      ? deepMerge(base[k], v)
      : v;
  }
  return out;
}

function ensureDataDir() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
const kbSettingsFile = (vaultPath) => path.join(vaultPath, '.maestro', 'settings.json');

// The newest copy of your settings from the knowledge base or your home folder (null if there is none).
function findBackup() {
  const home = readJson(path.join(HOME_DIR, 'settings.json'));
  const kb = home && home.vaultPath ? readJson(kbSettingsFile(home.vaultPath)) : null;
  return [kb, home].filter(Boolean).sort((a, b) => (b.savedAt || 0) - (a.savedAt || 0))[0] || null;
}

function snapshot(cfg) {
  const out = { savedAt: Date.now() };
  for (const k of PERSIST) if (cfg[k] !== undefined) out[k] = cfg[k];
  return out;
}

// Copy settings to the knowledge base and home folder. Only rewrites a file when something changed.
function backup(cfg) {
  const snap = snapshot(cfg);
  const body = (o) => JSON.stringify({ ...o, savedAt: 0 });
  const write = (file) => {
    try {
      const old = readJson(file);
      if (old && body(old) === body(snap)) return;
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file + '.tmp', JSON.stringify(snap, null, 2), { mode: 0o600 });
      fs.renameSync(file + '.tmp', file);
    } catch { /* read-only folder: the data/ copy still works */ }
  };
  if (cfg.vaultPath && fs.existsSync(cfg.vaultPath)) write(kbSettingsFile(cfg.vaultPath));
  write(path.join(HOME_DIR, 'settings.json'));
}

// Settings saved in a knowledge base folder, used when you point a fresh install at your existing vault.
function readKbSettings(vaultPath) { return readJson(kbSettingsFile(vaultPath)); }

function load() {
  ensureDataDir();
  let saved = {};
  if (fs.existsSync(CONFIG_FILE)) {
    try { saved = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); } catch { saved = {}; }
  } else {
    const b = findBackup(); // fresh download: bring back your connections and settings
    if (b) {
      delete b.savedAt;
      saved = b;
      try { fs.writeFileSync(CONFIG_FILE, JSON.stringify(b, null, 2)); } catch {}
    }
  }
  const cfg = deepMerge(defaultConfig(), saved);
  // connections are replaced wholesale, not merged, so disconnecting sticks
  if (saved.connections) cfg.connections = { business: {}, personal: {}, ...saved.connections };
  // The assistant used to be called Jarvis; older installs move to Maestro.
  if (!cfg.assistantName || /^jarvis$/i.test(cfg.assistantName)) cfg.assistantName = 'Maestro';
  // Older installs spoke at 1.05; Ryan asked for slower, calmer speech (2026-11-02).
  if (cfg.voice && (cfg.voice.rate === 1.05 || cfg.voice.rate === 1)) cfg.voice.rate = 0.92;
  // Ryan (2026-11-02): at most 1.5 s of silence between sentences, now measured as the whole gap. Older saved pauses move to it once.
  // Ryan (2026-11-02, later): half of that, 0.75 s.
  if (cfg.voice && (cfg.voice.pause == null || !(saved.voice && saved.voice.pauseRev === 3))) { cfg.voice.pause = 750; cfg.voice.pauseRev = 3; }
  if (!path.isAbsolute(cfg.vaultPath)) cfg.vaultPath = path.resolve(ROOT, cfg.vaultPath);
  return cfg;
}

function save(cfg) {
  ensureDataDir();
  const tmp = CONFIG_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2));
  fs.renameSync(tmp, CONFIG_FILE);
  backup(cfg);
  return cfg;
}

function update(mutator) {
  const cfg = load();
  mutator(cfg);
  return save(cfg);
}

// Never send API keys to the browser; show only whether one is set.
function publicView(cfg) {
  const copy = JSON.parse(JSON.stringify(cfg));
  for (const p of ['anthropic', 'openai', 'gemini', 'compatible']) {
    if (copy.llm[p]) copy.llm[p].apiKey = copy.llm[p].apiKey ? '••••' + copy.llm[p].apiKey.slice(-4) : '';
  }
  if (copy.oauth) for (const o of Object.values(copy.oauth)) if (o && o.clientSecret) o.clientSecret = '••••' + String(o.clientSecret).slice(-4);
  for (const prof of Object.values(copy.connections || {})) {
    for (const c of Object.values(prof)) {
      if (c.oauth) c.oauth = { signedIn: !!c.oauth.refresh, email: c.oauth.email || '', provider: c.oauth.provider || '' }; // tokens never leave this computer
      if (c.fields) for (const k of Object.keys(c.fields)) if (/token|secret|password|key/i.test(k) && c.fields[k]) c.fields[k] = '••••';
    }
  }
  return copy;
}

module.exports = { ROOT, DATA_DIR, CONFIG_FILE, HOME_DIR, FOUNDATION, load, save, update, publicView, defaultConfig, readKbSettings };
