#!/usr/bin/env node
// Maestro MCP server for Claude Desktop (stdio transport, zero dependencies).
// Claude is the reasoning engine; this server gives it the brain: vault knowledge, memory,
// the intelligence feed, calendar, tasks and skills. Register it with `npm run connect-claude`.
const path = require('path');
const readline = require('readline');

const core = path.join(__dirname, '..', 'core');
const config = require(path.join(core, 'config'));
const vault = require(path.join(core, 'vault'));
const feed = require(path.join(core, 'feed'));
const calendar = require(path.join(core, 'calendar'));
const tasks = require(path.join(core, 'tasks'));
const agents = require(path.join(core, 'agents'));
const brain = require(path.join(core, 'brain'));
const connectors = require(path.join(core, 'connectors'));

const VERSION = require('../package.json').version;
const SUPPORTED = ['2025-11-25', '2025-06-18', '2025-03-26', '2024-11-05'];
const log = (...a) => process.stderr.write('[maestro-mcp] ' + a.join(' ') + '\n');

const fmtTime = (iso) => new Date(iso).toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' });

const TOOLS = [
  {
    name: 'maestro_brief',
    description: "Get everything needed for a briefing on the user's day: today's calendar, high-priority feed items, open tasks and memory. Use this first when the user asks what's going on, to brief them, or what to focus on.",
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    run: async () => {
      const cfg = config.load();
      const ctx = await brain.gatherContext('brief today priorities', cfg.profile);
      return `User: ${cfg.user.name} (${cfg.user.role}). Profile: ${cfg.profile}. Now: ${new Date().toLocaleString()}\n\n` + brain.contextText(ctx, cfg, cfg.profile);
    },
  },
  {
    name: 'search_brain',
    description: "Search the user's Obsidian vault (notes, projects, people, meetings, decisions, memory) by keywords. Returns matching notes with excerpts and paths.",
    inputSchema: { type: 'object', properties: { query: { type: 'string' }, limit: { type: 'number', description: 'Max results (default 6)' } }, required: ['query'], additionalProperties: false },
    run: async ({ query, limit }) => {
      const hits = vault.search(query, { limit: limit || 6 });
      if (!hits.length) return `No notes match "${query}".`;
      return hits.map((h) => `## ${h.title}\npath: ${h.path}\n${h.excerpt}`).join('\n\n');
    },
  },
  {
    name: 'read_note',
    description: 'Read a full note from the vault by path (e.g. "Projects/Sprint 24.md") or by title.',
    inputSchema: { type: 'object', properties: { path: { type: 'string' }, title: { type: 'string' } }, additionalProperties: false },
    run: async ({ path: p, title }) => {
      let rel = p;
      if (!rel && title) { const n = vault.findByTitle(title); if (!n) throw new Error(`No note titled "${title}"`); rel = n.path; }
      if (!rel) throw new Error('Give a path or a title');
      return vault.readNote(rel).raw;
    },
  },
  {
    name: 'write_note',
    description: 'Create, append to, or overwrite a Markdown note in the vault. Use [[wikilinks]] to connect it to related notes. Prefer folders: Inbox/, Projects/, Meetings/, People/, Decisions/, Personal/.',
    inputSchema: { type: 'object', properties: { path: { type: 'string', description: 'Relative path, e.g. "Meetings/2026-11-03 Sprint Review.md"' }, content: { type: 'string' }, mode: { type: 'string', enum: ['create', 'append', 'overwrite'], description: 'Default create (fails if the note exists)' } }, required: ['path', 'content'], additionalProperties: false },
    run: async ({ path: p, content, mode = 'create' }) => {
      const exists = vault.loadNotes(true).some((n) => n.path === p || n.path === p + '.md');
      if (mode === 'create' && exists) throw new Error('That note already exists. Use mode "append" or "overwrite".');
      const rel = vault.writeNote(p, content, { append: mode === 'append' });
      feed.add({ source: 'system', profile: config.load().profile, category: 'PROJECT', title: `Claude ${mode === 'append' ? 'updated' : 'saved'} a note`, quote: rel, summary: 'Written from Claude Desktop', notePath: rel });
      return `Saved ${rel}`;
    },
  },
  {
    name: 'remember',
    description: "Save a lasting fact about the user (a preference, decision, person, or context) to the brain's memory log so it is used in every future answer.",
    inputSchema: { type: 'object', properties: { fact: { type: 'string' } }, required: ['fact'], additionalProperties: false },
    run: async ({ fact }) => `Remembered in ${brain.remember(fact, 'Claude Desktop')}`,
  },
  {
    name: 'get_memory',
    description: "Read the user's memory notes: profile, preferences, working style and the memory log.",
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    run: async () => vault.loadNotes().filter((n) => n.folder === 'Memory').map((n) => `# ${n.title}\n${n.body}`).join('\n\n---\n\n'),
  },
  {
    name: 'get_feed',
    description: 'Get the intelligence feed: normalised notifications from email, Gmail, Outlook, calendars, Slack, texts, calls and role-pack tools (Linear, Jira, Figma, GitHub…).',
    inputSchema: { type: 'object', properties: { source: { type: 'string', description: 'Connector id, e.g. slack, gmail, outlook, gcal, twilio_sms, linear, github' }, category: { type: 'string', enum: ['EMAIL', 'CONVERSATION', 'SMS', 'CALL', 'MEETING', 'TASK', 'PROJECT', 'INSIGHT'] }, limit: { type: 'number' } }, additionalProperties: false },
    run: async ({ source, category, limit }) => {
      const items = feed.list({ source, category, limit: limit || 25 });
      if (!items.length) return 'No feed items match.';
      return items.map((i) => `- [${i.category}] ${i.sourceName} · ${brain.ago(i.ts)} · ${i.title}${i.quote ? ' — ' + i.quote : ''}${i.summary ? ' (' + i.summary + ')' : ''}${i.priority ? ' · ' + i.priority : ''}${i.deadline ? ' · ' + i.deadline : ''}`).join('\n');
    },
  },
  {
    name: 'get_calendar',
    description: "Get the user's calendar events for the next N days (default 7).",
    inputSchema: { type: 'object', properties: { days: { type: 'number' } }, additionalProperties: false },
    run: async ({ days }) => {
      const ev = await calendar.list({ days: days || 7 });
      return ev.map((e) => `- ${fmtTime(e.start)}–${new Date(e.end).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })} · ${e.title}${e.attendees ? ' · with ' + e.attendees.join(', ') : ''}${e.location ? ' · ' + e.location : ''}`).join('\n') || 'No events.';
    },
  },
  {
    name: 'create_event',
    description: "Create a calendar event for the user. Saves it to Maestro's calendar and, when the user's iCloud/CalDAV calendar has sign-in details in Maestro, writes it there too. Ask the user for any missing detail (day, time, length, title, location, description) before calling. For Google Calendar or Outlook, prefer those Claude connectors if they are available.",
    inputSchema: { type: 'object', properties: { title: { type: 'string' }, start: { type: 'string', description: 'ISO 8601 start, e.g. 2026-11-02T14:00:00 (local time if no offset)' }, duration_minutes: { type: 'number' }, attendees: { type: 'array', items: { type: 'string' } }, location: { type: 'string' }, description: { type: 'string', description: 'Notes or agenda for the event' }, calendar: { type: 'string', description: 'Calendar name from list_calendars; defaults to the first writable calendar' } }, required: ['title', 'start'], additionalProperties: false },
    run: async ({ title, start, duration_minutes, attendees, location, description, calendar: calName }) => {
      const ev = require('../core/events');
      const { targets } = await ev.targets();
      const t = (calName && targets.find((x) => x.name.toLowerCase() === String(calName).toLowerCase())) || targets[0];
      const r = await ev.create({ title, start, minutes: duration_minutes || 30, attendees: attendees || [], location, notes: description || '' }, { target: t.id });
      return `Created "${r.event.title}" ${new Date(r.event.start).toLocaleString()} – ${new Date(r.event.end).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })} in ${t.id === 'maestro' ? 'the Maestro calendar' : `${t.name} (${t.via})`}.${r.warning ? ' ' + r.warning : ''}`;
    },
  },
  {
    name: 'list_calendars',
    description: 'List the calendars Maestro can create events in.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    run: async () => { const { targets, notes } = await require('../core/events').targets(); return targets.map((t) => `- ${t.name} (${t.via})`).join('\n') + (notes.length ? '\n\n' + notes.join('\n') : ''); },
  },
  {
    name: 'list_tasks',
    description: 'List open tasks from the vault (Obsidian checkboxes), highest priority first.',
    inputSchema: { type: 'object', properties: { include_done: { type: 'boolean' } }, additionalProperties: false },
    run: async ({ include_done }) => tasks.list({ includeDone: !!include_done }).map((t) => `- [${t.done ? 'x' : ' '}] ${t.text}${t.priority ? ' · ' + t.priority : ''}${t.due ? ' · due ' + t.due : ''} (path: ${t.path}, line: ${t.line})`).join('\n') || 'No open tasks.',
  },
  {
    name: 'get_priorities',
    description: "Look up the user's projects (dates, milestones, progress, open tasks), Maestro's ranking of the most important tasks, and the risks that could stop them hitting their goals (overdue work, milestones close with open tasks, projects behind schedule, a packed calendar, urgent messages). Use it when asked what to focus on, what matters most, what's at risk, or about a project.",
    inputSchema: { type: 'object', properties: { project: { type: 'string', description: 'Optional project name to look up' } }, additionalProperties: false },
    run: async ({ project }) => {
      const focus = require('../core/focus');
      const profile = config.load().profile;
      let events = [];
      try { events = await calendar.list({ profile, days: 30 }); } catch { /* no calendar */ }
      if (project) { const a = focus.answer(`tell me about the ${project} project`, { profile, events }); if (a) return a; }
      return focus.contextBlock({ profile, events });
    },
  },
  {
    name: 'add_task',
    description: 'Add a task to the vault inbox (Tasks/Inbox.md).',
    inputSchema: { type: 'object', properties: { text: { type: 'string' }, due: { type: 'string', description: 'YYYY-MM-DD' }, priority: { type: 'string', enum: ['High', 'Medium', 'Low'] } }, required: ['text'], additionalProperties: false },
    run: async ({ text, due, priority }) => `Added: ${tasks.add(text, { due, priority })}`,
  },
  {
    name: 'complete_task',
    description: 'Toggle a task done/undone using the path and line from list_tasks.',
    inputSchema: { type: 'object', properties: { path: { type: 'string' }, line: { type: 'number' } }, required: ['path', 'line'], additionalProperties: false },
    run: async ({ path: p, line }) => (tasks.toggle(p, line) ? 'Marked done' : 'Reopened'),
  },
  {
    name: 'log_decision',
    description: 'Record a decision in the vault (Decisions/) with context, options considered and rationale, so the brain can recall why something was decided.',
    inputSchema: { type: 'object', properties: { title: { type: 'string' }, decision: { type: 'string' }, rationale: { type: 'string' }, stakeholders: { type: 'string' }, project: { type: 'string' } }, required: ['title', 'decision'], additionalProperties: false },
    run: async ({ title, decision, rationale, stakeholders, project }) => {
      const rel = `Decisions/${brain.isoDate()} ${title.replace(/[\\/:*?"<>|]/g, '')}.md`;
      vault.writeNote(rel, `---\ntags: [decision]\ndate: ${brain.isoDate()}\n---\n# ${title}\n\n**Decision:** ${decision}\n\n**Why:** ${rationale || ''}\n\n**Stakeholders:** ${stakeholders || ''}\n\n${project ? `Project: [[${project}]]\n\n` : ''}Back to [[Decision Log]]`);
      return `Logged ${rel}`;
    },
  },
  {
    name: 'list_skills',
    description: "List the brain's skills (reusable playbooks like sprint briefing, design critique, release summary).",
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    run: async () => agents.skills().map((s) => `- ${s.name}: ${s.description}`).join('\n') || 'No skills installed.',
  },
  {
    name: 'get_skill',
    description: 'Get the step-by-step instructions for a skill by name. Follow them to complete the task.',
    inputSchema: { type: 'object', properties: { name: { type: 'string' } }, required: ['name'], additionalProperties: false },
    run: async ({ name }) => {
      const s = agents.skills().find((x) => x.name.toLowerCase() === name.toLowerCase() || x.slug === name.toLowerCase());
      if (!s) throw new Error('No skill named ' + name);
      return `# ${s.name}\n${s.instructions}`;
    },
  },
  {
    name: 'list_agents',
    description: "List the specialist agents loaded into the brain (e.g. @Product, @Design, @Dev). Each agent is a persona with its own instructions that shares the same knowledge base.",
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    run: async () => agents.agents().map((a) => `- @${a.handle} (${a.name})${a.role ? ': ' + a.role : ''}${a.description ? ' — ' + a.description : ''}${a.skills.length ? ' · skills: ' + a.skills.join(', ') : ''}`).join('\n') || 'No agents loaded.',
  },
  {
    name: 'get_agent',
    description: 'Load an agent persona by handle (e.g. "Product"). Adopt its instructions for the rest of the task and use the Maestro tools for knowledge.',
    inputSchema: { type: 'object', properties: { handle: { type: 'string' } }, required: ['handle'], additionalProperties: false },
    run: async ({ handle }) => {
      const a = agents.findAgent(handle);
      if (!a) throw new Error('No agent @' + handle);
      const sk = agents.skills().filter((s) => a.skills.map((x) => x.toLowerCase()).includes(s.name.toLowerCase()));
      return `# @${a.handle} — ${a.name}\n${a.prompt}${sk.length ? '\n\n## Skills this agent uses\n' + sk.map((s) => `### ${s.name}\n${s.instructions}`).join('\n\n') : ''}`;
    },
  },
  {
    name: 'create_skill',
    description: 'Teach the brain a new reusable skill (a playbook). Saved to Skills/ in the vault so every agent, the dashboard and Claude can use it.',
    inputSchema: { type: 'object', properties: { name: { type: 'string' }, description: { type: 'string' }, triggers: { type: 'string', description: 'Comma-separated phrases that should trigger it' }, instructions: { type: 'string', description: 'Markdown steps' } }, required: ['name', 'instructions'], additionalProperties: false },
    run: async (args) => `Saved ${agents.createSkill(args)}`,
  },
  {
    name: 'create_agent',
    description: 'Create a new specialist agent in the brain (saved to Agents/ in the vault). It shares the same knowledge base and can be @mentioned in the dashboard.',
    inputSchema: { type: 'object', properties: { name: { type: 'string' }, handle: { type: 'string' }, role: { type: 'string' }, description: { type: 'string' }, prompt: { type: 'string', description: 'System instructions for the agent' } }, required: ['name'], additionalProperties: false },
    run: async (args) => `Saved ${agents.createAgent(args)}`,
  },
  {
    name: 'list_unsynced_events',
    description: 'Events the user created in Maestro for Google Calendar, Outlook or iCloud that still need copying into that calendar. Create each one with your calendar connector, then call mark_event_synced.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    run: async () => {
      const list = require('../core/events').pendingSync();
      const gone = require('../core/removed').pendingSync();
      if (!list.length && !gone.length) return 'Nothing to sync. Every event created or removed in Maestro is already done in its calendar.';
      const CAL = { gcal: 'Google Calendar', outlook: 'Outlook', icalendar: 'iCloud / Apple Calendar' };
      return [...gone.map((r) => JSON.stringify({ action: 'delete', uid: r.uid, calendar: CAL[r.needsSync] || r.needsSync, title: r.title, start: r.start, whole_series: r.series || undefined })),
        ...list.map((e) => JSON.stringify({ action: 'create', uid: e.uid, calendar: { gcal: 'Google Calendar', outlook: 'Outlook', icalendar: 'iCloud / Apple Calendar' }[e.calendarFor] || e.calendarFor, title: e.title, start: e.start, end: e.end, location: e.location || undefined, description: e.notes || undefined, attendees: e.attendees && e.attendees.length ? e.attendees : undefined }))].join('\n');
    },
  },
  {
    name: 'mark_event_synced',
    description: 'Mark an item from list_unsynced_events as done in the real calendar (after creating or deleting it there with your calendar connector). Pass start too for a deletion of one occurrence.',
    inputSchema: { type: 'object', properties: { uid: { type: 'string' }, start: { type: 'string' } }, required: ['uid'], additionalProperties: false },
    run: async ({ uid, start }) => (require('../core/events').markSynced(uid) || require('../core/removed').markSynced(uid, start) ? 'Marked as synced.' : 'Nothing pending with that uid.'),
  },
  {
    name: 'remove_event',
    description: "Remove an event from the user's calendar through Maestro (iCloud/CalDAV directly, Calendly cancels the booking and notifies the invitee, Google/Outlook are queued for list_unsynced_events). Always confirm the exact event with the user first. Identify it by words from its title or attendees and, if needed, the day.",
    inputSchema: { type: 'object', properties: { event: { type: 'string', description: 'Words from the title or attendee, e.g. "board prep" or "meeting with John"' }, date: { type: 'string', description: 'Optional day, e.g. "tomorrow" or "friday"' }, whole_series: { type: 'boolean', description: 'For repeating events: remove every occurrence' } }, required: ['event'], additionalProperties: false },
    run: async ({ event, date, whole_series }) => {
      const rm = require('../core/remove');
      const found = await rm.candidates(`${event} ${date || ''}`, config.load().profile);
      if (!found.length) return 'No upcoming event matches that.';
      if (found.length > 1) return 'Several events match; ask the user which one, then call again with more detail:\n' + found.slice(0, 6).map((e) => `- ${e.title} · ${fmtTime(e.start)} (${e.source})`).join('\n');
      const r = await rm.perform(found[0], { series: !!whole_series });
      return r.done + (r.note ? ' ' + r.note : '');
    },
  },
  {
    name: 'add_feed_items',
    description: 'Push notifications into the Maestro Intelligence Feed for a source the user connected in Claude Desktop (Slack, Linear, Jira, Notion, Figma, Google Drive, GitHub, Gmail…). Call this after reading new messages or activity with that connector. Items are de-duplicated by id, so re-sending is safe.',
    inputSchema: { type: 'object', properties: {
      source: { type: 'string', description: 'Maestro connector id, e.g. slack, linear, jira, notion, figma, gdrive, github, gmail, outlook' },
      items: { type: 'array', maxItems: 50, items: { type: 'object', properties: {
        id: { type: 'string', description: 'Stable id from the source (message ts, issue key, URL…)' },
        title: { type: 'string', description: 'Short headline, e.g. "Alex Chen in #launch" or "PLAT-88 moved to QA"' },
        text: { type: 'string', description: 'The message or a one-line excerpt' },
        time: { type: 'string', description: 'ISO time it happened' },
        summary: { type: 'string', description: 'Why it matters, one short line' },
        priority: { type: 'string', enum: ['High', 'Medium', ''] },
        action: { type: 'string', description: 'Suggested next step, e.g. "Reply in thread"' },
        url: { type: 'string' },
      }, required: ['title'], additionalProperties: false } },
    }, required: ['source', 'items'], additionalProperties: false },
    run: async ({ source, items }) => {
      const def = connectors.get(source);
      const cfg = config.load();
      const profile = Object.keys(cfg.connections).find((p) => cfg.connections[p][source] && cfg.connections[p][source].mode === 'claude') || cfg.profile;
      let added = 0;
      for (const i of items) {
        const ts = Date.parse(i.time || '') || Date.now();
        const it = feed.add({ externalId: `claude:${source}:${i.id || i.url || i.title + '|' + (i.time || '')}`, ts, source, profile, category: (def && def.category) || 'INSIGHT', title: i.title, quote: i.text ? '"' + String(i.text).slice(0, 240) + '"' : '', summary: i.summary || '', priority: i.priority || '', actions: i.action ? [i.action] : [], url: i.url || '', viaClaude: true, unread: Date.now() - ts < 24 * 3600000 });
        if (it) added++;
      }
      const conn = (cfg.connections[profile] || {})[source];
      const note = conn ? '' : ` Note: ${def ? def.name : source} is not connected in Maestro's ${profile} profile yet, so these stay hidden until the user connects it with "I connected it in Claude Desktop".`;
      return `Added ${added} new item${added === 1 ? '' : 's'} to the ${profile} feed (${items.length - added} already there).${note}`;
    },
  },
  {
    name: 'list_connections',
    description: 'Show which sources are connected to the brain in each profile (demo or live).',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    run: async () => {
      const cfg = config.load();
      return Object.entries(cfg.connections).map(([prof, c]) => `${prof}: ` + (Object.entries(c).map(([id, v]) => `${(connectors.get(id) || { name: id }).name} (${v.mode})`).join(', ') || 'none')).join('\n') + `\nActive profile: ${cfg.profile}`;
    },
  },
  {
    name: 'switch_profile',
    description: 'Switch the brain between the Business and Personal profile.',
    inputSchema: { type: 'object', properties: { profile: { type: 'string', enum: ['business', 'personal'] } }, required: ['profile'], additionalProperties: false },
    run: async ({ profile }) => { config.update((c) => { c.profile = profile; }); return `Profile is now ${profile}`; },
  },
];

// What to read for each source the user marked "I connected it in Claude Desktop".
function syncPrompt() {
  const cfg = config.load();
  const lines = [];
  for (const [prof, conns] of Object.entries(cfg.connections)) {
    for (const [id, c] of Object.entries(conns)) {
      if (c.mode !== 'claude') continue;
      const def = connectors.get(id) || { name: id };
      const chans = c.fields && Array.isArray(c.fields.channels) && c.fields.channels.length ? c.fields.channels.map((x) => '#' + String(x).replace(/^#/, '')).join(', ') : '';
      lines.push(`- ${def.name} (source "${id}", ${prof} profile)` + (id === 'slack' ? `: my mentions and DMs${chans ? `, plus new messages in ${chans}` : ''}` : ': new activity that involves me'));
    }
  }
  if (!lines.length) return 'No sources are marked as connected through Claude Desktop in Maestro yet. Tell me to open Maestro → MCP Connections, pick a source and choose "I connected it in Claude Desktop".';
  return ['Bring my latest activity into the Maestro feed.', '', 'For each source below, use your connector for it to read what happened in the last 24 hours:', ...lines, '',
    'Then call the Maestro add_feed_items tool once per source with up to 30 items, newest first. For each item: id = the message ts / issue key / URL, title = "<person> in #<channel>" (or the issue / doc name), text = the message (one or two lines), time = ISO time, summary = why it matters if anything, priority = High when someone is waiting on me, otherwise Medium for direct mentions and DMs, empty for the rest.',
    'Skip messages I sent myself. If a connector is not available in this chat, say which one and continue with the rest. Finish with one line: how many items you added per source.'].join('\n');
}

function send(msg) { process.stdout.write(JSON.stringify(msg) + '\n'); }
function reply(id, result) { send({ jsonrpc: '2.0', id, result }); }
function fail(id, code, message) { send({ jsonrpc: '2.0', id, error: { code, message } }); }

async function handle(msg) {
  const { id, method, params = {} } = msg;
  const isRequest = id !== undefined && id !== null;
  try {
    switch (method) {
      case 'initialize': {
        const v = SUPPORTED.includes(params.protocolVersion) ? params.protocolVersion : SUPPORTED[0];
        const cfg = config.load();
        return reply(id, {
          protocolVersion: v,
          capabilities: { tools: {}, prompts: {}, resources: {} },
          serverInfo: { name: 'maestro', title: 'Maestro Second Brain', version: VERSION },
          instructions: `Maestro is ${cfg.user.name}'s second brain (Obsidian vault + memory + intelligence feed). Call maestro_brief or get_memory early for context, search_brain before answering questions about their work or life, and use remember / write_note / log_decision to keep the brain up to date. Cite notes as [[Title]].`,
        });
      }
      case 'notifications/initialized':
      case 'notifications/cancelled':
        return;
      case 'ping':
        return reply(id, {});
      case 'tools/list':
        return reply(id, { tools: TOOLS.map(({ name, description, inputSchema }) => ({ name, description, inputSchema })) });
      case 'tools/call': {
        const tool = TOOLS.find((t) => t.name === params.name);
        if (!tool) return fail(id, -32602, 'Unknown tool ' + params.name);
        try {
          const text = await tool.run(params.arguments || {});
          return reply(id, { content: [{ type: 'text', text: String(text) }] });
        } catch (e) {
          return reply(id, { content: [{ type: 'text', text: 'Error: ' + e.message }], isError: true });
        }
      }
      case 'prompts/list': {
        const arg = [{ name: 'focus', description: 'Optional extra focus or details', required: false }];
        return reply(id, { prompts: [
          { name: 'sync-calendar-events', title: 'Sync my calendar changes into my calendars', description: 'Copy events you created or removed in Maestro into Google Calendar, Outlook or iCloud using your Claude connectors.', arguments: arg },
          { name: 'sync-claude-sources', title: 'Sync my Claude connectors into Maestro', description: 'Read new activity from the sources you connected in Claude Desktop (Slack, Linear, Jira…) and put it in the Maestro feed.', arguments: arg },
          ...agents.skills().map((s) => ({ name: 'skill-' + s.slug, title: 'Skill: ' + s.name, description: s.description || s.name, arguments: arg })),
          ...agents.agents().map((a) => ({ name: 'agent-' + a.handle.toLowerCase(), title: `Agent: @${a.handle}`, description: a.description || a.role || a.name, arguments: arg })),
        ] });
      }
      case 'prompts/get': {
        const name = String(params.name || '');
        const focus = params.arguments && params.arguments.focus ? `\n\nFocus: ${params.arguments.focus}` : '';
        if (name === 'sync-calendar-events') return reply(id, { description: 'Sync Maestro events into my calendars', messages: [{ role: 'user', content: { type: 'text', text: 'Call the Maestro list_unsynced_events tool. For each item with action "create", create it in the calendar it names (Google Calendar, Outlook or iCloud) with your connector for that calendar, using the same title, start, end, location, description and attendees. For each item with action "delete", find that event in the named calendar (same title and start time) and delete it (the whole series if whole_series is true, otherwise only that occurrence). After each one, call mark_event_synced with its uid (and start for deletions). If you have no connector for a calendar, skip those events and tell me which. Finish with one line per calendar: how many events you added.' + focus } }] });
        if (name === 'sync-claude-sources') return reply(id, { description: 'Sync Claude connectors into Maestro', messages: [{ role: 'user', content: { type: 'text', text: syncPrompt() + focus } }] });
        if (name.startsWith('agent-')) {
          const a = agents.findAgent(name.slice(6));
          if (!a) return fail(id, -32602, 'Unknown prompt');
          return reply(id, { description: a.description, messages: [{ role: 'user', content: { type: 'text', text: `For this conversation, act as my Maestro agent @${a.handle}. Use the Maestro tools (get_memory, search_brain, get_feed, get_calendar, list_tasks) for knowledge before answering.\n\n${a.prompt}${focus}` } }] });
        }
        const s = agents.skills().find((x) => 'skill-' + x.slug === name || x.slug === name);
        if (!s) return fail(id, -32602, 'Unknown prompt');
        return reply(id, { description: s.description, messages: [{ role: 'user', content: { type: 'text', text: `Run my "${s.name}" skill using the Maestro tools.\n\n${s.instructions}${focus}` } }] });
      }
      case 'resources/list':
        return reply(id, { resources: vault.loadNotes().filter((n) => ['Memory', '(root)'].includes(n.folder)).map((n) => ({ uri: 'maestro://vault/' + encodeURI(n.path), name: n.title, mimeType: 'text/markdown' })) });
      case 'resources/read': {
        const rel = decodeURI(String(params.uri || '').replace('maestro://vault/', ''));
        return reply(id, { contents: [{ uri: params.uri, mimeType: 'text/markdown', text: vault.readNote(rel).raw }] });
      }
      default:
        if (isRequest) return fail(id, -32601, 'Method not found: ' + method);
    }
  } catch (e) {
    log('error', e.stack || e.message);
    if (isRequest) fail(id, -32603, e.message);
  }
}

const rl = readline.createInterface({ input: process.stdin });
rl.on('line', (line) => {
  if (!line.trim()) return;
  let msg;
  try { msg = JSON.parse(line); } catch { return fail(null, -32700, 'Parse error'); }
  if (Array.isArray(msg)) msg.forEach(handle); else handle(msg);
});
rl.on('close', () => process.exit(0));
log(`ready (vault: ${config.load().vaultPath})`);
